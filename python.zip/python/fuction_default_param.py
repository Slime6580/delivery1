def say_myself(name, age, man=True,):
    print("이름 : %s" % name)
    print("나이 : %")