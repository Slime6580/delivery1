def add_many(*args):
    result = 0
    for i in args:
        result += i
    return result

list = add_many(1,2,3,4,5)
print(list)