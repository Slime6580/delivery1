add = () lambda a, b : a+b
print(add(4,5))