for i in range(2, 10):
    for j in range (1,10):
        print(i, "x",j,"=",i*j, end="\n")
    print('')

    a=[1,2,3,4]
    result=[num*3 for num in a if num %2 ==0]
    print(result)