class Bird:
    def fly(self):
        raise NotImplementedError