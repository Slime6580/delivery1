PI = 3.141592

def add(a,b):
    return a+b

def sub(a,b):
    return a-b

class Math:
    def 

if __name__ == "__main__":
    print(add(3,4))
