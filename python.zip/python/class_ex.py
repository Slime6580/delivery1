class Calculator:
    def __init__(self):
        self.result = 0

    def add(self, num):
        result = 10
        self.result += num
        print(result) 
        return self.result

    def sub(self, num):
        self.result -= num
        return self.result
    
cal1 = Calculator()
cal2 = Calculator()

sum = cal1.add(3)
sum = cal1.add(4)

print(sum)


