file = open("새파일3.txt",'a')
for i in range(20,30):
    data = "%d번째 줄입니다.\n" % i
    file.write(data)
file.close()