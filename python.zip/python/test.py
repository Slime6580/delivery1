from mod1 import *

sum = add(3,4)
print(PI)
math = Math()
area = math.solv(30)
print(area)