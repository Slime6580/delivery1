a=10
def vartest(b):
    global a
    c=a+b
    print('지역변수 ',a)
    print('지역변수 ',c)

vartest(10)
print('전역변수' ,a)
