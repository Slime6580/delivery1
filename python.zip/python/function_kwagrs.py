def print_kwargs(**kwargs):
    print(kwargs)

print_kwargs(no=1, b=2, c=200, name='홍길동')

def add_and_mul(a,b):
    return a+b, a*b

print(add_and_mul(2,3))