import sys

args = sys.argv[1:]
for i in args:
    print(i)
    