<template>
    <div v-on:click="countClicks">
        <h2>
            {{ name }}
            <p> {{ message }} </p>
            <p id="red">you have clicked me {{ clicks }} times. </p>
        </h2>
    </div>
</template>
<style>

</style>
<script>
    export default {
        data() {
            return{
                name : '사과',
                message : '감자튀김 먹고싶다',
                clicks : 0,
            }
        },
        methods :{
            countClicks() {
                this.clicks++;
            } 
        }

    }


</script>