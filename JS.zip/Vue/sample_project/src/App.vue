
<template>
  
    <h1> food </h1>
    <food-item/>
    <food-item/>
    <food-item/>

</template>
  
<style scoped>

#app > div {
  border : dashed black 1px;
  display: inline-block;
  margin : 10px;
  padding: 10px;
  background-color: lightgreen;
}

</style>
  <script>
    export default {
      data(){
        return {
          messge : 'this is some text',
        }
      }
    };
  </script>