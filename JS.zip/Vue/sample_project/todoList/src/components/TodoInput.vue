<template>
  <div class="inputBox shadow">
      <input type="text" v-model="newTodoItem"
      v-on:keyup.enter="addTodo">
      <span calss="addContainer"
      v-on:click="addTodo">
      <i class="far fa-plus-square addBtn"></i>
    </span>
  </div>
</template>

<style>
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  float: right;
  background: linear-gradient(to right, #62EAC6, #32CEE6);
  display: block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.addBtn {
  color: white;
  vertical-align: middle;
}
</style>
<script>

export default {
  data: function() {
    return {
      newTodoItem: ""
    }
  },
  methods : {
    addTodo: function() {
      console.log(this.newTodoItem);
      // 저장하는 로직
      localStorage.setItem(this.newTodoItem, this.newTodoItem);
      this.clearInput();
      // this.newTodoItem = "";
    },
    clearInput : function(){
      this.newTodoItem="";
    }

  }
}
</script>