<template>
    <div class="clearAllContainer">
        <spna class="clearAllBtn" v-on:click="clearTodo">
        clear All </spna>
    </div>

</template>

<script>
export default {
    methods : {
        clearTodo : function(){
            localStorage.clear();
        }
    }

}

</script>

<style>
.clearAllContainer {
    width: 8.5rem;
  height: 50px;
  line-height: 50px;
  background-color: white;
  border-radius: 5px;
  margin: 0 auto;
}
.clearBtn {
  color: #e20303;
  display: block;
}

</style>