<template>
    <div>
      <ul>
        <li v-for="todoItem in todoItems" v-bind:key="todoItem">
          {{ todoItem }}
          <span class="removeBtn" v-on:click="removeTodo(todoItem, index)">
           삭제 <i class="fas fa-trash-alt"></i>
          </span>
        </li>
      </ul>
    </div>
  </template>

<script>

export default {
    data : function(){
        return {
            todoItems : []
        }
    },
    created : function() {
        if(localStorage.length > 0) {
            for(let i=0; i<localStorage.length; i++){
                if(localStorage.key(i) !== 'loglevel:webpack-dev-server')
                this.todoItems.push(localStorage.key(i));
            }
        }
    },
    methods: {
    removeTodo: function(todoItem, index) {
      localStorage.removeItem(todoItem);
      this.todoItems.splice(index, 1);
      }
    }
}

</script>

<style>
ul {
  list-style-type: none;
  padding-left: 0;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
</style>