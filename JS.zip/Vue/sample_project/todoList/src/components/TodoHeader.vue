<template>
    <header>
        <h1> Todo it </h1>
    </header>
</template>

<style> 
h1{
    color: grey;
    font-weight: 900;
    margin: 2.5rem 0 1.5rem;
}
</style>