package com.simple.threadex;

import static java.lang.Thread.sleep;

class Counter {
    private int value = 0;

    public synchronized void increment() {
        value++;
    }

    public synchronized void decrement(){
        value--;
    }

    public void printCounter(){
        System.out.println(value);
    }
}

public class CounterThread {
    Counter shredCounter;
    public CounterThread(Counter c) {
        this.shredCounter = c;
    }

    public void run() {
        int i=0;
        while (i<200){
            shredCounter.increment();
            shredCounter.decrement();
            if (i%40 == 0) {
                shredCounter.printCounter();
                try {
                    sleep((int)(Math.random()*2));
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            i++;

        }
    }
}
//public class CounterTest {
//    public static void main(String[] args) {
//
//        Counter counter = new Counter();
//
//
//
//    }
//}
