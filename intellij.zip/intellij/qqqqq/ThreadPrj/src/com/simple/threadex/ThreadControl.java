package com.simple.threadex;

public class ThreadControl {

    static void print(String message){
        String threadName = Thread.currentThread().getName();
        System.out.format("%s:%s%n",threadName,message);

    }
    private static class MessageLoop implements Runnable {
        @Override
        public void run(){

            String message[] = {"안녕하세요",
            "자바 스레드 학습중.",
            "스레트 제어부분을 학습중",
            "메시지를 출력합니다."};

            try{
                for (int i=0; i< message.length; i++) {
                    print(message[i]);
                    Thread.sleep(2000);
                }
                } catch (InterruptedException e){
                    print("아직 끝나지 않음");
                }
            }
        }


    public static void main(String[] args) throws InterruptedException {
        int tries = 0;

        print("추가적인 스레드를 시작합니다.");
        Thread t = new Thread(new MessageLoop());
        t.start();

        print("추가적인 스레드가 끝나기를 기다립니다");
        while (t.isAlive()){
            print("아직 기다립니다.");
            t.join(1000);
            tries++;
            System.out.println("시도 횟수 : "+tries);
            if (tries > 2) {
                print("견딜수가 읍다");
                t.interrupt();
                t.join();
            }
        }
        print("메인 스레드 종료");
    }


}
