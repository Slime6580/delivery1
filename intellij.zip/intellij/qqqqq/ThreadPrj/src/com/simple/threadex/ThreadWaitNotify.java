package com.simple.threadex;

class ThreadB extends Thread {
    int total;
    public void run() {
        for (int i=0; i<5; i++){
            System.out.println(i+"를 더합니다.");
            total += i;
          try {
              Thread.sleep(500);
          }catch (InterruptedException e) {
              throw new RuntimeException(e);
          }
        }

    }
}
public class ThreadWaitNotify {
    public static void main(String[] args) {

        ThreadB thB = new ThreadB();
        thB.start();
        Thread th1 = new ThreadB();
    }
}
