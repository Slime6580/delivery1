package com.simple.threadex;

class MyThread1 extends Thread {
    public void run() {

        for (int i = 10; i >= 0; i--) {
            System.out.print(i + " ! ");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

public class MyThread {
    public static void main(String[] args) throws InterruptedException {
        Thread myThread1 = new MyThread1();
        myThread1.start();
        for (int i = 10; i >= 0; i--) {
            System.out.print(i + " ");
            Thread.sleep(1000);
        }
        myThread1.start();
    }
}
