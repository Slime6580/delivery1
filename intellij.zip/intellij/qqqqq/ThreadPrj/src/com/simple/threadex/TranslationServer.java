package com.simple.threadex;

public class TranslationServer {
}
