package com.simple.threadex;

class MyThread3 extends Thread {
    int sum=0;
    public int getSum ;


    public void run(){

        for (int i=0; i<10; i++){

        }
            try {
                Thread.sleep((int)(Math.random()*1000));
            }catch (InterruptedException e){
                e.printStackTrace();
            }
    }
}


public class Thread_join {
    public static void main(String[] args) {
        MyThread3 t3 = new MyThread3();
        try {
            t3.join();
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("종료");
        System.out.println("합계 : ");
    }
}
