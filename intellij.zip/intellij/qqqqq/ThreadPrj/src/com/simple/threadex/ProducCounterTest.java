package com.simple.threadex;

class Buffer {
    private int data;
    private boolean empty = true;

    public synchronized int get(){
        while (empty){
            try {
                wait();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        empty = true;
        notifyAll();
        return data;
    }
    public synchronized void put(int data){
        while (!empty){
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        empty = false;
        this.data = data;
        notifyAll();
    }
}
class Producer implements Runnable {
    private Buffer buffer;

    public Producer(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
    for (int i=0; i<10; i++){
        buffer.put(i);
        System.out.println("생산자가 "+i+"번 감자칩을 생산하였습니다.");
        try {
            Thread.sleep((int)(Math.random()*100));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
            }
        }
    }
}

class Consumer implements Runnable {
    private Buffer buffer;

    public Consumer(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            int data = buffer.get();
            System.out.println("소비자가 " + data + "번 감자칩을 소비하였습니다.");
            try {
                Thread.sleep((int) (Math.random() * 100));
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
        public class ProducCounterTest {
            public static void main(String[] args) {
                Buffer buffer = new Buffer();
                Thread producer = new Thread(new Producer(buffer));
                Thread consumer = new Thread(new Consumer(buffer));

                producer.start();
                consumer.start();
            }
}
