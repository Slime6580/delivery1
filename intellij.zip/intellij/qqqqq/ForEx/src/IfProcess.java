import java.time.LocalDate;
import java.util.Scanner;

public class IfProcess {
    public static void main(String[] args) {

// 입력 : 나이
        int age;

        Scanner input = new Scanner(System.in);
        System.out.println("나이 : ");
        String age_ = input.nextLine();
        age = Integer.parseInt(age_);

// 오늘의 날짜
        LocalDate now = LocalDate.now();
        int MonthOfYear = now.getMonthValue();
        int dayOfMonth = now.getDayOfMonth();
        System.out.println("오늘은 "+MonthOfYear+"월 "+dayOfMonth+"일 입니다.");

// 나이 마지막 자리수 처리
        if( (age%10) > 0){
        } else {
            System.out.println("나이를 잘못 입력하셨습니다.");
            return;
        }
// 출력 : 진료 가능 여부
        if( (age%10)==(dayOfMonth%10) ){
            System.out.println("진료가능");
        } else {
            System.out.println("진료불가능");
        }
    }
}
