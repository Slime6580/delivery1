import java.util.Scanner;

public class jogun1 {
    public static void main(String[] args) {
        int age, mon, day, day1, age1;
        Scanner scan = new Scanner(System.in);
        do {
            System.out.printf("정확한 월을 입력하세요[1-12] ");
            mon = scan.nextInt();
        } while (!(mon >= 1 && mon <= 12));
        do {
            System.out.printf("정확한 일을 입력하세요[1-31]");
            day = scan.nextInt();
            day1 = day % 10;
        } while (day < 1 || day > 31); {
        System.out.println(mon + "월 " + day + "일");
        System.out.printf("나이를 입력하세요 : ");
        age = scan.nextInt();
        age1 = age % 10; }
        while (age1 == day1) {
            System.out.printf("금일 진료가 가능합니다");
            return;
        }
        System.out.printf("금일 진료가 불가합니다");
    }
}