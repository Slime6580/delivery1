
import java.util.Scanner;

public class test1 {
    public static void main(String[] args) {

        // 입력 : 나이
        // 조건 : 나이 끝자리와 날자 끝자리가 일치해야 진료를 받을 수 있다.
        // 출력 : 진료를 받을 수 있는가

        int age;
        Scanner kbd = new Scanner(System.in);
        System.out.print("나이 : ");
        String age_ = kbd.nextLine();
        age = Integer.parseInt(age_);

        int day;
        Scanner kbd1 = new Scanner(System.in);
        System.out.print("날자 : ");
        String day_ = kbd1.nextLine();
        day = Integer.parseInt(day_);

        int num1 = age % 10;
        int num2 = day % 10;

        System.out.println("num1의 값"+num1+"num2의 값"+num2);

        if ( num1 == num2) ;
        {
            System.out.println("진료 가능합니다");
        }

        System.out.print("진료 불가");
    }
}