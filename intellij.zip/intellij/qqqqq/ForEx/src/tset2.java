import java.util.Scanner;

public class tset2 {
    public static void main(String[] args) {

        // 입력 : 키
        // 조건 : 키를 입력받아 골고루 반에 배치
        // 출력 : 1, 2, 3 반 출력

        int ky; // 키
        Scanner kbd = new Scanner(System.in);
        System.out.print("키 :");
        String ky_ = kbd.nextLine();
        ky = Integer.parseInt(ky_);

        int i = 1; // 반복제어용
        int sum=0;
        while(i <= 3){
            sum = i;
            System.out.print("배치된 반 : "+sum);
            i++;
        }

    }
}
