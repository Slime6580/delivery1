import java.util.Arrays;
import java.util.Scanner;

public class GoTest {
    public static void main(String[] args) {
        Scanner kbd = new Scanner(System.in);
        int[] array = new int[kbd.nextInt()];
        for (int i = 0; i<array.length; i++) {
            array[i] = kbd.nextInt();
            System.out.println(i + " 번째 값 : "+array[i]);
        }
        System.out.print("배열 : ");
        for (int i=0; i<array.length; i++)
            System.out.print(array[i]+" ");

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int i = 0; i< array.length; i++) {
            if (array[i] > max)
                max = array[i];
            if (array[i] < min)
                min = array[i];
        }
        System.out.println();
        System.out.println("최대값 : "+max);
        System.out.println("최소값 : "+min);

        int sum = 0;
        for (int i = 0; i< array.length; i++) {
            if (array[i] % 2 == 0)
                sum += array[i];
        }
        System.out.println("짝수의 합 : "+sum);

        Arrays.sort(array);
        System.out.print("정리된 배열 : ");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
}
