package car;

public class Sedan extends Car{
    @Override
    public void run() {
        System.out.println("300km 속도로 달린다");
    }

    @Override
    public void gasInput() {
        System.out.println("15만원 어치 주유");
    }

    public void manOfCar() {
        System.out.println("탑승 인원은 4명");
    }
}
