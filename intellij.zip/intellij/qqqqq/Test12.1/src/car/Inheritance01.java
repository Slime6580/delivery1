package car;

public class Inheritance01 {
    public static void main(String[] args) {

        Car.display();

        Sedan s = new Sedan();
        s.run();
        s.gasInput();

        Truck t = new Truck();
        t.run();
        t.gasInput();



    }
}
