package car;

public class Truck extends Car{
    @Override
    public void run() {
        System.out.println("150km 속도로 달린다");
    }

    @Override
    public void gasInput() {
        System.out.println("30만원 어치 주유");
    }

    public void manOfCar() {
        System.out.println("탑승인원이 2명입니다");
    }
}
