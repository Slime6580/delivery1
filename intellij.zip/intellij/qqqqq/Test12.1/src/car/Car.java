package car;

public class Car {
    public int tire;
    public int engine;
    public int capacity;

    public Car() {

    }
    public void run(){
        System.out.println("도로위를달린다");
    }
    public void gasInput() {
        System.out.println("기름을주유");
    }
    public static void display() {
        System.out.println("현재자동차의상태를표시");
    }
}
