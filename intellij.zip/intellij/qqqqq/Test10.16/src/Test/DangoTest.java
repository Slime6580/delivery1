package Test;

public class DangoTest {
}
