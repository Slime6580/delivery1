package Test;

import java.util.Scanner;

public class Dango {
    new Scanner
}
