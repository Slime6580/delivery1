
public class Main {
    public static void main(String[] args) {

        String name = "시라카미";
        int count;

        count = name.length();

        System.out.println("이름:"+name);
        System.out.println("이름 글자수:"+count);
        }
    }
