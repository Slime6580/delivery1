package System;

public class Start {
    public static void main(String[] args) {

        new Controll();
        new Type();
        new Yoyaku();



    }
}
