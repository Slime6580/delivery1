package com.simple.filereadwrite;

import java.io.*;
import java.util.Date;

public class ObjectStreamTest {
    public static void main(String[] args) throws IOException, InterruptedException {
        ObjectInputStream in = null;
        ObjectOutput out = null;

        try {
            out = new ObjectOutputStream( new FileOutputStream("object.dat"));
            out.writeObject(new Date());
            out.flush();

            in = new ObjectInputStream(new FileInputStream("object.dat"));
            Date d = (Date) in.readObject();
            System.out.println("날짜 시간 : "+d);
            Thread.sleep(3000);
            System.out.println("날짜 시간 : "+d.getSeconds());

        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
    }
}
