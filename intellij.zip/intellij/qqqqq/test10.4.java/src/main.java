public class main {
    public main(String[] args) {


        final int SIZE = 3;

        int[] num = new int[SIZE];

        int i;
        {
            for (i = 0; i < 3; i++) {
                num[i] = (int) (Math.random() * 100);
                System.out.println("학생의 국어, 영어, 수학 점수 : " + num[i]);
            }

            int total = 0;
            double average;

            for (int k = 0; k < 3; k++) {

                total += num[k];

                average = (double) total / 3;
                System.out.println("A학생의 평균 : " + (float) average);
                System.out.println("");
            }
        }

        int y;
        {
            for (y = 0; y < 3; y++) {
                num[y] = (int) (Math.random() * 100);
                System.out.println("학생들의 영어 점수 : " + num[y]);
            }

            int total = 0;
            double average;

            for (int j = 0; j < 3; j++) {

                total += num[j];

                average = (double) total / 3;
                System.out.println("영어 점수의 평균 : " + (float) average);

            }
        }

        int t;
        {
            for (t = 0; t < 3; t++) {
                num[t] = (int) (Math.random() * 100);
                System.out.println("학생들의 수학 점수 : " + num[t]);
            }

            int total = 0;
            double average;

            for (int j = 0; j < 3; j++) {

                total += num[j];

                average = (double) total / 3;
                System.out.println("수학 점수의 평균 : " + (float) average);

            }
        }
    }
}