package CalTest;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

class ComboBoxEx extends JFrame {
    String[] time = {"아침", "점심", "저녁", "간식"};
    String[] name = {"구운 계란", "바나나", "닭가슴살(100g)", "미숫가루", "제육볶음", "돼지국밥", "햄버거", "짜장면", "순두부찌개", "김치찌개",
            "삼겹살", "부대찌개", "떡볶이"};

    private int Protein = 0;
    private int Fat = 0;
    private int Cab = 0;
    private int Cal = 0;
    private int result = 0;
    private int result1 = 0;

    ComboBoxEx() {
        this.setTitle("탄단지칼 계산기");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new FlowLayout());
        JPanel contentPane = new JPanel();
        JLabel sumLabel;
        JLabel sumLabel1;
        JLabel sumLabel2;
        setContentPane(contentPane);
        sumLabel = new JLabel(" ");
        JLabel chackLabel;

        chackLabel = new JLabel();

        JComboBox strCombo = new JComboBox(time);
        this.add(strCombo);

        JComboBox nameCombo = new JComboBox(name);
        this.add(nameCombo);

        JButton btnNewButton = new JButton("저장");
        btnNewButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println(nameCombo.getSelectedIndex());
                if (nameCombo.getSelectedIndex() == 0){
                    Cal += 307; Cab += 1; Protein += 6; Fat += 5;
                } else if (nameCombo.getSelectedIndex() == 1) {
                    Cal += 439; Cab += 27; Protein += 1;
                } else if (nameCombo.getSelectedIndex() == 2) {
                    Cal += 458; Protein += 23; Fat += 1;
                } else if (nameCombo.getSelectedIndex() == 3) {
                    Cal += 586; Cab += 27; Protein += 5; Fat += 1;
                } else if (nameCombo.getSelectedIndex() == 4) {
                    Cal += 572; Cab += 31; Protein += 39; Fat += 33;
                } else if (nameCombo.getSelectedIndex() == 5) {
                    Cal += 307; Cab += 23; Protein += 27; Fat += 10;
                } else if (nameCombo.getSelectedIndex() == 6) {
                    Cal += 426; Cab += 31; Protein += 22; Fat += 23;
                } else if (nameCombo.getSelectedIndex() == 7) {
                    Cal += 785; Cab += 129; Protein += 27; Fat += 20;
                } else if (nameCombo.getSelectedIndex() == 8) {
                    Cal += 259; Cab += 5; Protein += 18; Fat += 18;
                } else if (nameCombo.getSelectedIndex() == 9) {
                    Cal += 128; Cab += 8; Protein += 8; Fat += 8;
                } else if (nameCombo.getSelectedIndex() == 10) {
                    Cal += 700; Cab += 1; Protein += 36; Fat += 59;
                } else if (nameCombo.getSelectedIndex() == 11) {
                    Cal += 626; Cab += 41; Protein += 27; Fat += 38;
                } else if (nameCombo.getSelectedIndex() == 12) {
                    Cal += 280; Cab += 60; Protein += 7; Fat += 3;
                }
                System.out.println((String) strCombo.getSelectedItem());
                System.out.println((String) nameCombo.getSelectedItem());

                sumLabel.setText("칼로리 :" + Cal + "단백질" + Protein + "지방" + Fat + "탄수화물" + Cab);

                chackLabel.setText((String) nameCombo.getSelectedItem());

            }
        });

        sumLabel1 = new JLabel(" ");
        sumLabel2 = new JLabel(" ");

        JButton btnNewButton1 = new JButton("계산");
        btnNewButton1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if (Protein <= 49) {
                    result = 50 - Protein;
                    sumLabel1.setText(result+"만큼의 단백질을 더 섭취해야해요!");
                }else if (Protein >=50 && Protein <=70) {
                    sumLabel1.setText("하루 적정량의 단백질을 섭취했어요!");
                }else {
                    sumLabel1.setText("하루에 너무 많은 단백질을 섭취했어요!" +
                            " 과한 단백질 보충은 간에 무리를 줘요!");
                    }

                if (Cal <= 2200) {
                    result1 = 2200 - Cal;
                    sumLabel2.setText(result1+"만큼의 칼로리가 부족해요!");
                }else if (Cal >=2000 && Cal <= 2500) {
                    sumLabel2.setText("하루 권장량의 칼로리를 섭취했어요!");
                }else {
                    sumLabel2.setText("너무 과하게 많은 칼로리를 섭취했어요!");

                }
            }

        });

        this.setLocationRelativeTo(null);
        this.setSize(450, 150);
        this.setVisible(true);
        contentPane.add(btnNewButton);
        contentPane.add(btnNewButton1);
        add(sumLabel);
        add(chackLabel);

        add(sumLabel1);


        add(sumLabel2);

    }

}

class Test {
    public static void main(String[] args) {
        new ComboBoxEx();
    }
}