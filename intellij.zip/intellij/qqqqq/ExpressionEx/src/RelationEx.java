public class RelationEx {

    public static void main(String[] arge) {
        int x=8;
        int y=5;
        boolean result;

        result = !(x >= y) && (x>7);
        System.out.println("결과 : " + result);

    }
}
