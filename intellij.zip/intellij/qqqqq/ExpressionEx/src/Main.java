
public class Main {
    public static void main(String[] args) {
        int num = 21;
        int result;
        boolean even1=true;
        boolean even2=true;
        // 홀수 짝수 구분

        result = num % 2;
        even1 = result == 0;
        even2 = result == 1;
        System.out.println("나머지 : "+result);
        System.out.println("짝수인가 : "+even1);
        System.out.println("홀수인가 : "+even2);

        }
    }