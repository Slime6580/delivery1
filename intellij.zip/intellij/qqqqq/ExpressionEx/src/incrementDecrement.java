public class incrementDecrement {

    public static void main(String[] args) {
        int x=10;
        int y=10;

        int resultx;
        int resulty;

        resultx = x++;
        resulty = y--;

        System.out.println("결과 x : " +resultx);
        System.out.println("결과 x : " +x);

        System.out.println("결과 y : " +resultx);
        System.out.println("결과 y : " +y);
    }
}
