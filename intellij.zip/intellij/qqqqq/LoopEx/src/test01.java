import java.util.Scanner;

public class test01 {
    public static void main(String[] args) {

        //입력변수
        int month;
        String input="";

        Scanner kbd = new Scanner(System.in);
        do {
            System.out.print("월을 입력(1~12) : ");
            input = kbd.nextLine();
            month = Integer.parseInt(input);
        }while ( !(month >=1 && month <= 12));

        // 처리할 내용
        // 정확한 월을 입력하였는지 비교
        // 정확한 월을 입력 할 때 까지 반복 처리

        // 출력
        // 사용자가 입력한 월을 출력



    }
}
