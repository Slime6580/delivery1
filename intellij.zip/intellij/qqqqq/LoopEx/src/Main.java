
public class Main {
    public static void main(String[] args) {

        // 반복문 while : 조건에 따라 반복

        int i = 0; // 반복제어용
        int sum=0;
        while(i <= 100){
            //sum = i+sum;
            sum += i; //누적 공식
            System.out.println("중간 합 : "+sum);
            i++;      // couter 식
        }

        System.out.println("반복을 종료합니다.");
        System.out.println("최종 값 :"+sum);

    }
}