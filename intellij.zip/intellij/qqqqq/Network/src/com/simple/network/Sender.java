package com.simple.network;

import java.net.*;

public class Sender {
    public static void main(String[] args) throws SocketException, UnknownHostException {
        DatagramSocket socket = null;

        socket = new DatagramSocket();
        String s = "너희는 아직 준비가 안됐다";
        byte[] buf = s.getBytes();
        System.out.println(buf);

        // 보낼 상대의 주소 설정
        InetAddress address = InetAddress.getByName("127.0.0.1");
        DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 5000);



    }
}
