package com.simple.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Translator extends Thread{
    Socket socket;
    int myId;


    public Translator (Socket accept, int clientId) {
        this.socket = socket;
        this.myId = clientId;
    }

    public void run() {
        try {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            System.out.println("안녕하세요? 클라이언트 번호는 "+myId+"입니다");
            System.out.println("단어를 입력하세요");

            while (true){
                String input = in.readLine();
                if(input == null) break;
                if(input.equals("java")==true) {
                   // out.println(input+"->자바");
                }
            }
        }catch (IOException e) {
            System.out.println("클라이언트 번호 : "+myId+"처리 실패");
        }finally {
            try {
                socket.close();
            }catch (IOException e) {
                System.out.println("소켓 종료 중 오류");
            }
        }
    }
}
