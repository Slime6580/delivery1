package com.simple.network;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

public class DownloadImageFileURL {
    public static void main(String[] args) throws IOException {
        URL site = new URL("https://t1.daumcdn.net/daumtop_chanel/op/20200723055344399.png");
        byte[] buffer = new byte[2048];

        InputStream in = site.openStream();
        OutputStream out = new FileOutputStream("daumlogo.png");
        int lenght = 0;
        while ((lenght = in.read(buffer))!=-1){
            System.out.println(""+lenght+"바이트 만큼 읽음");
            out.write(buffer, 0, lenght);
        }
        in.close();
        out.close();}

}
