package com.simple.network;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class DateServer {
    public static void main(String[] args) throws IOException {

        ServerSocket ss = null;

        while (true) {
            Socket socket = null;
            try {
                socket = ss.accept();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            PrintWriter out = null;
            try {
                Thread.sleep(1000);
                out = new PrintWriter(socket.getOutputStream(), true);
            } catch (IOException | InterruptedException e) {
                throw new RuntimeException(e);
            } finally {
                    socket.close();
            }
            out.println(new Date().toString());
            try {
                ss.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }


        }


    }
}

