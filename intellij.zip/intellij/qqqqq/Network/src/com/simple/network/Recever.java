package com.simple.network;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Recever {
    public static void main(String[] args) throws IOException{
        byte[] buf = new byte[10];

        DatagramSocket socket = new DatagramSocket(5000);
        DatagramPacket packet = new DatagramPacket(buf,buf.length);
        DatagramPacket packet1 = new DatagramPacket(buf,buf.length);
        socket.receive(packet);
        System.out.println(new String(buf));
        socket.receive(packet1);
        System.out.println(new String(buf));


    }
}
