package com.simple.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class DateClient {
    public static void main(String[] args) throws IOException {

        Socket ss = new Socket("localhost", 9100);
        BufferedReader input =
                new BufferedReader(new InputStreamReader(ss.getInputStream()));
        String result = input.readLine();
        System.out.println(result);
        System.exit(0);

    }
}

