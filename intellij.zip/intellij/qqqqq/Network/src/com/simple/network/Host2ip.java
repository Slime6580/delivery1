package com.simple.network;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Host2ip {
    public static void main(String[] args) throws UnknownHostException {

        String hostname="www.naver.com";
        InetAddress address = InetAddress.getByName(hostname);

        System.out.println(address+", "+address.getHostAddress());



    }
}
