package com.simple.network;

import com.sun.java.accessibility.util.Translator;

import java.io.IOException;
import java.net.ServerSocket;

public class TranslationServer {
    public static void main(String[] args) throws IOException {
        System.out.println("영어 번역 서버가 실행중입니다");

        int clientId = 0;

        ServerSocket ss = new ServerSocket(9101);
        try {
            while (true) {
                clientId++;
               // Translator t = new Translator(ss.accept(), clientId);
               // t.start();
            }
        }finally {
            ss.close();
        }
    }
}
