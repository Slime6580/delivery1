package com.simple.network;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TranslationClient extends JFrame implements ActionListener {

    private BufferedReader in;
    private PrintWriter out;
    private JTextField field;
    private JTextArea area;

    public TranslationClient() throws Exception, IOException {
        setTitle("클라이언트");
        setSize(500,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 객체생성
        field = new JTextField(50);
        field.addActionListener(this);
        area = new JTextArea(10,50);
        area.setEditable(false);

        Socket socket = new Socket("192.168.1.13",9101);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        area.append(in.readLine()+"\n");
        area.append(in.readLine()+"\n");



        // 객체 이벤트 처리

        // 객체 등록
        add(field, BorderLayout.NORTH);
        add(area, BorderLayout.SOUTH);



        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        out.println(field.getText());
        String reponse = null;

        try {
            reponse = in.readLine();
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        area.append(reponse+"\n");
    }

    public static void main(String[] args) throws Exception {
        TranslationClient client = new TranslationClient();
    }
}
