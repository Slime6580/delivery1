import java.util.Scanner;

public class lab {

    public static void main(String[] args) {
        // 입력 : 원의 반지름
        // 반지름 : 정수입력
        // 출력 : 원의 면적
        // 면적 : 실수 출력

        int radius = 5;
        double area;
        Scanner input = new Scanner(System.in);
        System.out.println("반지름 :");
        String radius_ = input.nextLine();
        radius = Integer.parseInt(radius_);

        // 면적 : area = 3.14*radius*radius;
        area = 3.14*radius*radius;
        System.out.println("반지름:"+radius);
        System.out.println("원의 면적:"+area);

        double num1;
        num1 = 3.14;

        int num2;
        Scanner input2 = new Scanner(System.in);
        System.out.println("반지름 :");
        String num2_ = input.nextLine();
        num2 = Integer.parseInt(num2_);

        double result;

        result = num1 * num2 * num2 ;

        System.out.print(num1+"*"+num2+"*"+num2+"="+result);


    }
}