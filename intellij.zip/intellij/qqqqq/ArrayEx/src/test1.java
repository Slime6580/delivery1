import java.util.Scanner;

public class test1 {
    public static void main(String[] args) {

        int jumsu1 ;
        int jumsu2 ;




        Scanner kbd1 = new Scanner(System.in);
        System.out.print("정수1 : ");
        String jumsu1_ = kbd1.nextLine();
        jumsu1 = Integer.parseInt(jumsu1_);

        Scanner kbd = new Scanner(System.in);
        System.out.print("정수2 : ");
        String jumsu2_ = kbd.nextLine();
        jumsu2 = Integer.parseInt(jumsu2_);

        System.out.println("정수1 : "+jumsu1+" 정수 2: "+jumsu2);

        char op ;

        Scanner kbd2 = new Scanner(System.in);
        System.out.print("연산자 : ");
        String op_ = kbd2.nextLine();
        op = (char) Integer.parseInt(op_);

        if ( op=='+') {
            System.out.println(jumsu1+"+"+jumsu2+"="+(jumsu1+jumsu2));
        }
        else if ( op=='-') {
            System.out.println(jumsu1+"-"+jumsu2+"="+(jumsu1-jumsu2));
        }


    }
}
