public class test2 {
    public static void main(String[] args) {


        final int SIZE = 3;

        int[] num = new int[SIZE];

        for (int i = 0; i < 3; i++) {
            num[i] = (int) (Math.random() * 100);
            System.out.println(" 학생들의 국어 점수 : " + num[i]); }

            int total = 0;
            double average;

            for (int j = 0; j < 3; j++) {

                total += num[j];

                average = (double) total / 3;
                System.out.println("국어 점수의 평균 : " + average);



            }
        }
    }