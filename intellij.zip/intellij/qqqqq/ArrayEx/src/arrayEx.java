
public class arrayEx {
    public static void main(String[] args) {

        // 배열 : n개의 데이터를 저장
        // 참조방법 : 인덱스를 이용하여 참조( s[2] )

        final int SIZE = 10;

        int[] num = new int[SIZE];

        for (int i = 0; i < SIZE; i++) {
            num[i] = (int) (Math.random() * 6);
            System.out.println(i + 1 + " : " + num[i]);
        }

        //int total = 0;
        //double average;
        int searchkey = 3;
        boolean search = false;

        // n개의 평균을 구하시오.
        // searchkey 를 모두 찾으시오
        for (int i = 0; i < 10; i++) {
            // 특정한 값을 검색하기
            if (searchkey == num[i]) {
                System.out.println("찾았다" + "위치" + i + "번째");
                search = true;
                break;
            }
        }
        if(!search) {
            System.out.println("값을 찾을 수 없습니다");
        }
    }
}

