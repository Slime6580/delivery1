package com.simple.exception;

public class ExceptionBasic {
    public static void main(String[] args) {
        int[] array = new int[10];
        for(int i=0; i<10; i++){
            array[i] = 0;
        }

        array[0] = 100;
        int divider = 0;
        int mok = 0;
        int result = 0;

        try {
            mok = array[0] / divider;
        }catch (ArithmeticException e) {
            mok = 100;
           // e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            System.out.println("사용한 자원을 해제합니다");
        }

        try {
            result = array[12];
        }catch (ArithmeticException e) {
            result = 1000;
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            System.out.println("사용한 자원을 해제합니다");
        }


        // int result = array[12];
        System.out.println("몫 : "+mok);
        System.out.println("배열 값 : "+result);
    }
}
