package com.simple.oop02.saikoro;

import java.util.Random;

public class player {

    public int hand;
    Random rand = new Random();

    public player() {
        hand = rand.nextInt(6+1);
    }

    public static void main(String[] args) {
        player player_ = new player();
        System.out.println(player_.hand);

    }}









