package com.simple.oop02.interfaceex;

public interface OperateCar {
    void start();
    void stop();
    void setSpeed(int speed);
    void turn(int degree);

}
