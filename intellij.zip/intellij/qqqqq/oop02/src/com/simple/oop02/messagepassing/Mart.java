package com.simple.oop02.messagepassing;

import java.util.Scanner;

public class Mart {
    public static void main(String[] args) {
        // 객체 생성
        FruitSeller seller = new FruitSeller();
        Buyer buyer = new Buyer();


        System.out.println("사과의 값 :"+seller.APPLE_PRICE);
        System.out.println("몇개살건데? :"+buyer.buyapple);
        System.out.println("합쳐서"+(seller.APPLE_PRICE*buyer.buyapple)+"원이야");
        int sellpice = (seller.APPLE_PRICE*buyer.buyapple);
        buyer.money -= sellpice;
        seller.myMoney += sellpice;
        System.out.println("구매자 남은 돈 : "+buyer.money);
        System.out.println("판매자 소지금 : "+seller.myMoney);
        buyer.numOfApple += buyer.buyapple;
        seller.numOfApple -= buyer.buyapple;
        System.out.println("구매자 소유 사과 : "+buyer.numOfApple);
        System.out.println("판매자 남은 과일 : "+seller.numOfApple);

        


    }
}
