package com.simple.oop02.oop2;

public class AcessControlTest {
    public static void main(String[] args) {
        AccessControl obj = new AccessControl();
       obj.ShowInfo();
       obj.setName("후부키");
       obj.ShowInfo();
        obj.setAge(18);
        System.out.println("나이:"+obj.getAge());





    }

}
