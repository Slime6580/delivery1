package com.simple.oop02.oop2;

public class InnerOuterTest {
    public static void main(String[] args) {

    Outer outer = new Outer();

    }
}
