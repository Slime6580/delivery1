package com.simple.oop02.oop2;

public class MethoopParam {
/*
    int value=0;

    void increment/{
        obj.value = obj.value +1;

    }


    void increment(MethoopParam obj){
        value = value + 1;

    }

    public static void main(String[] args) {
        MethoopParam m = new MethoopParam();
        int x = 10;
        m.increment(x);
        System.out.println("x = "+x);



        System.out.println();
        System.out.println();
                System.out.print();
        );

  */
    }

