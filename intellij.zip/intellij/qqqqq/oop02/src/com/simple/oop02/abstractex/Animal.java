package com.simple.oop02.abstractex;

public class Animal {
    public void move(int num) {

    }

    public void eat() {
        System.out.println("모든 동물은 무언가를 먹는다");





    }
}