package com.simple.oop02.polymorphism;

class Animal{}

public class Dog1 extends Animal{
    public static void main(String[] args) {
        Dog1 Dog1 = new Dog1();
        Dog1 =null;
        Dog1 dog3 = (Dog1) new Dog1();
        Dog1 dog2 = new Dog1();
        System.out.println(dog2 instanceof Animal);
        System.out.println(dog3 instanceof Dog1);



    }
}
