package com.simple.oop02.extendex;

public class Shape {
    private int x;
    private int y;

    public Shape(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public Shape() {

    }

    public int getX() {
        return x;
    }

    protected void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    protected void setY(int y) {
        this.y = y;
    }

    public void draw(){
        System.out.println("도형을 그립니다.");
    }



    void print(){
        System.out.println("도형을 그립니다.");
    }

}
