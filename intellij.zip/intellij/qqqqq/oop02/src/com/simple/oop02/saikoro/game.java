package com.simple.oop02.saikoro;

public class game {
    public static void main(String[] args) {


        int Pwin = 0;
        int Cwin = 0;
        int Drow = 0;

        for (int i=0; i<3; i++) {

            player player_ = new player();
            computer computer_ = new computer();

            System.out.println("컴퓨터의 주사위 눈 갯수 : "+computer_.Csaikoro);
            System.out.println("플레이어의 주사위 눈 갯수 : "+player_.hand);

            if (computer_.Csaikoro == player_.hand) {
                System.out.println("무승부");
                Drow++;

            } else if (computer_.Csaikoro < player_.hand) {
                System.out.println("플레이어의 승리");
                Pwin++;
                if (Pwin == 2) {
                    break;
                }
            } else {
                System.out.println("컴퓨터의 승리");
                Cwin++;
                if (Cwin == 2) {
                    break;
                }
            }
        }

        System.out.println("무승부 : "+Drow);
        System.out.println("플레이어 승리 : "+Pwin);
        System.out.println("컴퓨터의 승리 : "+Cwin);

    }

}
