package com.simple.oop02.extendex;

public class Car {
    int speed;

    public Car(int speed) {
        this.speed = speed;
    }
}
