package com.simple.oop02.oop2;

public class FieldInit {

    int speed;

    public FieldInit() {
        System.out.println("속도 :"+speed);
    }

    // 인스턴스 초기화 블럭
    {
        speed = 100;
        System.out.println("1 :"+speed);
    }

    public static void main(String[] args) {
        FieldInit fieldInit = new FieldInit();

        System.out.println("속도 :");

    }
}
