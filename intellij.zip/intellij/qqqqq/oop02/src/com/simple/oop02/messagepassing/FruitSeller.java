package com.simple.oop02.messagepassing;

public class FruitSeller {

    static final int APPLE_PRICE = 200;

    // 과일장수의 상태

    int numOfApple = 20;
    int numOforeng = 200;
    int myMoney = 50000;

    //과일 판매 행위
    public static int saleApple(int money){

        // 사과를 판다. -> 사과의 갯수가 줄어듬
        // 구매자 로부터 사과값을 받는다
        // 사과값을 계산
        // 사과를 구매자에게 준다
        int num = money / APPLE_PRICE;
   //     myMoney += money;
   //     numOfApple -= num;
        return num;
    }

   // 과일가게의 과일의 상태태를 받아줌
public void showkasutu(){
    System.out.println("사과" +numOfApple);
    System.out.println("오렌지" +numOforeng);
}
}

