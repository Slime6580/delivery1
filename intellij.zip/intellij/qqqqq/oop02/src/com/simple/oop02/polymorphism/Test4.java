/* package com.simple.oop02.polymorphism;

interface Printable{}

public InkJet implements Printable{

        }

public LaserPrint implements Printable {
    public void l(){
        System.out.printle("레이저 포인트");
    }

    class CallPinter {
        void invoke(Printable p){
            if (p instanceof InkJet) {
                InkJet inkjet = (InkJet) p;
                InkJet.a();
            } else if (p instanceof LaserPrint) {
                LaserPint laserPint = (LaserPint) p;
                laserPint.l();
            }
        }
    }




public class Test4 {
    public static void main(String[] args) {
    Printable p = new LaserPrint();
    Printable i = new InkJet();
    CallPinter c = new CallPinter();
    c.invoke(l);
    c.invoke(i);
        }
    } */