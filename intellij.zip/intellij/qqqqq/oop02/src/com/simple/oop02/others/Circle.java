package com.simple.oop02.others;

import com.simple.oop02.extendex.Shape;

public class Circle extends Shape {

    int radius;

    public Circle(int x, int y) {
        super(x, y);
    }

    public void draw(){
        setY(10);
        setX(20);
        System.out.println("중심점은 "+getX()+","+getY()+"입니다");
    }

}
class Triangle {
    Shape shape = new Shape(10, 20);

    public Triangle(int x, int y){
        super();
    }

    public void draw(){
    }
}