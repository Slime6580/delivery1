package com.simple.oop02.other;

import com.simple.oop02.oop2.AccessControl;

public class User {
    String id ="abcd";
    String password = "1234";
    String email = "999@aaaa.com";




    public static void main(String[] args) {
        AccessControl ather = new AccessControl();
       // other.addr = " 우주 ";

    }
}


