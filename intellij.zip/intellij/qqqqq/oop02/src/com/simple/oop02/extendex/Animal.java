package com.simple.oop02.extendex;

public class Animal {
    double weight;
    String picture;

    public Animal(double weight, String picture) {
        this.weight = weight;
        this.picture = picture;
    }

    public void eat() {
        System.out.println("모든 동물은 먹는다");
    }

    public void sleep() {
        System.out.println("모든 동물은 수면을 취한다");

    }

    public void speak(){
        System.out.println("동물은 동물 특유의 소리를 낸다.");
    }



}