package com.simple.oop02.extendex;

public class Lion extends Animal{
    int legs = 4;

    public Lion(double weight, String picture) {
        super(weight, picture);
    }

    void roar(){
        System.out.println(picture+ " 가 포효를 하다 ");
    }

    @Override
    public void speak() {
        System.out.println("사자는 그르렁 하고 짓는다.");
    }
}
