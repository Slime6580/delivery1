package com.simple.oop02.extendex;

import java.util.function.Predicate;

public class ShapeTest {
    public static void main(String[] args) {

        Shape s1, s2, s3;

        s1 = new Shape(10, 20);
        s2 = new Rectangle(10, 20, 100, 200);
        s3 = new Circle(10, 20, 50);

        s1.draw();
        s2.draw();
        s3.draw();


        Rectangle rectangle = new Rectangle(10, 10, 100, 200);

        System.out.println("면적은 "+rectangle.area());
        rectangle.print();
        rectangle.darw();




    }
}
