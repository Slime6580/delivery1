package com.simple.oop02.other;

public class Car {
    private String model;
    private String color;
    private int speed;

    // 자동차 시리얼 번호
    private int id;
    private static int numbers = 0;

    public Car(String model, String color, int speed) {
        this.model = model;
        this.color = color;
        this.speed = speed;
        // 자동차가 생성될 때 마다 부여되는 교유번호
        id = ++numbers;
    }

    public static void main(String[] args) {
        Car car1 = new Car("K5","white",200);
        System.out.println("생산된 자동차 수 : "+Car.numbers);
        Car car2 = new Car("K7","red",300);
        System.out.println("생산된 자동차 수 : "+Car.numbers);
        Car car3 = new Car("K9","black",100);
        System.out.println("생산된 자동차 수 : "+Car.numbers);
        System.out.println("생산된 자동차 수 : "+car3.id);
        System.out.println("생산된 자동차 수 : "+car3.numbers);
        Math.random();

    }
}
