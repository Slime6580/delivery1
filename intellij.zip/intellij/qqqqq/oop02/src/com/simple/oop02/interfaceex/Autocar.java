package com.simple.oop02.interfaceex;

public class Autocar implements OperateCar{

    int fuel=0;

    int speed;
    @Override
    public void start() {
        System.out.println("시동을 걸고 출발한다.");
    }

    @Override
    public void stop() {
        System.out.println("정지 한다.");
    }

    @Override
    public void setSpeed(int speed) {

        this.speed = speed;
        System.out.println("현재 속도 : "+speed);
    }

    @Override
    public void turn(int degree) {
        System.out.println("핸들을 "+degree+"로 이동합니다.");
    }

    public void fillFuel(int i){
        this.fuel += fuel;
    }

}
