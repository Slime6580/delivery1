package com.simple.oop02.extendex;

public class CarTest {
    public static void main(String[] args) {

        Car car1 = new Car(200);

        SportCar sportCar1 = new SportCar(300);
        sportCar1.setTurbo(true);






    }
}



