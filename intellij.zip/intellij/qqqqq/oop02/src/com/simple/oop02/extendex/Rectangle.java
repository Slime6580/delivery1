package com.simple.oop02.extendex;

public class Rectangle extends Shape{

    int x;

    int y;


    int width;

    int height;


    public Rectangle(int x, int y, int width, int height) {
        super();
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public int area(){
        return width*height;
    }

    public void darw(){
        System.out.println("사각형을 그립니다.");
        System.out.println("시작점은"+x+","+y+"입니다.");
    }

}
