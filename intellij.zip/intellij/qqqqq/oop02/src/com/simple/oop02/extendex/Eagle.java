package com.simple.oop02.extendex;

public class Eagle extends Animal{
    int wings=2;

    public Eagle(double weight, String picture) {
        super(weight, picture);
    }

    @Override
    public void speak() {
        System.out.println("독수리는 끼에에에엑ㄱ 하고 운다.");
    }

    public void speak(String str) {
        System.out.println("독수리는 끼에에에엑ㄱ 하고 운다.");
    }

    public void speak(String str, int n) {
        System.out.println("독수리는 끼에에에엑ㄱ 하고 운다.");
    }

    void fly(){
        System.out.println( picture + " 는 날 수 있다. ");
    }
}
