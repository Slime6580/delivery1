package com.simple.oop02.extendex;

public class AnimalTest {
    public static void main(String[] args) {

        Lion lion = new Lion(50,"고양이과");
        lion.sleep();
        lion.roar();
        lion.eat();
        lion.speak();
        // 사자 생성
        // 사자 기능 호풀

        Eagle eagle = new Eagle(10,"새과");
        eagle.fly();
        eagle.eat();
        eagle.sleep();
        eagle.speak();
        // 독수리 생성
        // 독수리 기능 호출





    }
}
