package com.simple.oop02.abstractex;

public class Lion extends Animal{

    @Override
    public void move(int num) {
        System.out.println(" 사자처럼 움직인다 ");
    }
}
