package com.simple.oop02.interfaceex;

public class AutoCarTest {
    public static void main(String[] args) {
        Autocar autocar = new Autocar();

        autocar.start();
        autocar.fillFuel(20);
        autocar.stop();
    }
}
