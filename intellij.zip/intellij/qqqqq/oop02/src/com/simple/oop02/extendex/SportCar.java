package com.simple.oop02.extendex;

public class SportCar extends Car{
    boolean turbo;

    public SportCar(int speed) {
        super(speed);
    }

    public void setTurbo(boolean turbo) {
        this.turbo = turbo;
    }




}
