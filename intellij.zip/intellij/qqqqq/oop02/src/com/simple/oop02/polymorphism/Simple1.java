package com.simple.oop02.polymorphism;

class Other {
    int num=10;
    public int getNum(){
        return num;
    }
}


public class Simple1 {
    public static void main(String[] args) {
        Simple1 simple1 = new Simple1();
        Other other = new Other();


        System.out.println(simple1 instanceof Simple1);
        System.out.println(other instanceof Other);

    }
}
