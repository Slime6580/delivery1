package com.simple.oop02.extendex;

public class Circle extends Shape{

    int radious;

    public Circle(int x, int y, int radious) {
        super(x, y);
    this.radious = radious;
    }



    public void darw(){
        System.out.println("사각형을 그립니다.");

    }

}
