package com.simple.oop02.car;

public class car {

    int Speed;
    int Oil = 0;
    boolean BrekeOn;
    boolean Axel;
    boolean Handle;

    public car(int oil, boolean brekeOn, boolean axel, boolean handle) {
        Oil = oil;
        BrekeOn = brekeOn;
        Axel = axel;
        Handle = handle;
    }
}
