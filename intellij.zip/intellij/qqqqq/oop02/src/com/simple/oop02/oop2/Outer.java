package com.simple.oop02.oop2;

public class Outer {
    private int value = 10;

    class InnerClass{
        public void myMethod(){
            System.out.println("외부 클래스 값 참조 : "+value);


        }
    }

    public Outer() {
        InnerClass obj = new InnerClass();
        obj.myMethod();

    }
}
