package com.simple.oop02.oop2;

public class Box {
    int width, length, height;
    int volume;

    public Box(int width, int length, int height) {
        this.width = width;
        this.length = length;
        this.height = height;
        volume = width * length * height;
    }

    public Box whosLargest(Box box1, Box box2) {
    if (box1.volume > box2.volume) {
        return new Box (box1.width, box1.height, box1.length);
    } else {
        return box2;
    }
}

    public static void main(String[] args) {
        Box box1 = new Box(10, 20, 50);
        Box box2 = new Box(10, 30, 30);
        Box box3= box1;
        if (box1.hashCode() == box2.hashCode()){
            System.out.println("box1");
        } else {
            System.out.println("box1과 box가 같지않음");
        }

        Box largest = box1.whosLargest(box1, box2);
        System.out.println("큰박스 성분:"+largest.width+","+largest.length+","+largest.height);
        box1.width=50;
        System.out.println("큰박스 성분:"+largest.width+","+largest.length+","+largest.height);



    }
}
