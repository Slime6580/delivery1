package com.simple.oop02.saikoro;

import java.util.Random;

public class computer {

    public int Csaikoro;

    Random rand = new Random();

    int num = (6+1);
    public computer() {
        Csaikoro = rand.nextInt(num);
    }

    public static void main(String[] args) {
        computer computer_ = new computer();
        System.out.println(computer_.Csaikoro);
    }
}


  