package com.simple.oop02.oop2;

public class AccessControl {
        private String name = "후레아";
        private int age = 25;
        private String addr = "지구 어딘가";

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    private String getAddr() {
        return "태양계"+addr;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        if(age<0 || age > 100) return;
        this.age = age;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    private  void getInfo(){
            System.out.println("이름 : "+name);
            System.out.println("나이 : "+age);
            System.out.println("주소 : "+addr);
       return;
        }

        public void ShowInfo(){
            System.out.println("이름 :" +getName());
            System.out.println("나이 :" +getAge());
            System.out.println("주소 :" +getAddr());

        }
}
