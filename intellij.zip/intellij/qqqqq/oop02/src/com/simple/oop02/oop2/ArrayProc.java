package com.simple.oop02.oop2;

import java.util.Scanner;

public class ArrayProc {
    // 배열 성적 저장
    final  static int STUDENTS = 5;
    public void getValues(int[] array){
        Scanner kbd = new Scanner(System.in);
        for (int i=0; i<array.length; i++){
            System.out.println("성적 입력 :");
         //   array[i] = kbd.nextLine();
        }
    }

    public double getAverarge(int[] array) {
        double total =0;
        for (int i=0; array.length<i; i++){
            total += array[i];
        }return total/array.length;

    }

    public static void main(String[] args) {
        int[] scores = new int[STUDENTS];
        ArrayProc array = new ArrayProc();
        array.getValues(scores);
        System.out.println("평균 : "+array.getAverarge(scores));
    }




    // 배열 성적 평균


}
