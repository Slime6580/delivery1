package com.simple.oop02.polymorphism;


class Animals{}

public class Dog3 extends Animal{

    public static String speak(){
        return ("왕왕");
    }
    static void methood(Animals a){
                Dog3 d;
                System.out.println("개는 "+speak()+"하고 짖는다");
            }

       public static void main(String[] args) {
            Animals a = new Animals();
            Animals a1 = new Animals();
            Dog3.methood(a1);;
        }

    }
