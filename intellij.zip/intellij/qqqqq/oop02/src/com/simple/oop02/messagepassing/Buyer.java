package com.simple.oop02.messagepassing;

import java.applet.Applet;
import java.util.Scanner;

public class Buyer {
    int money = 5000;
    int numOfApple =0;
    int numOfOrange =0;

    Scanner kbd = new Scanner(System.in);
    int buyapple = kbd.nextInt();





    // 구매가능
    public void buyApple(FruitSeller seller,int money){
        // 과일 장수에게 사과값을 구한다.
        // 과일 장수에게 사과 5개, 1000원치 달라고 한다.
        // 과일 장수에게 사과값에 해당하는 돈을 지불한다.
        // 과일 장수로부터 사과를 받아온다.
    numOfApple += buyapple;
    money -= FruitSeller.APPLE_PRICE * buyapple;

    }


}
