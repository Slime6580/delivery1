package com.simple.oop02.classex;

public class RectangleTest {
    public static void main(String[] args) {
        Rectangle r = new Rectangle(10,20);
        int area = r.calcArea();
        System.out.println("면적 : "+area);
        int area2 = r.calcArea(200, 250);
        System.out.println("면적 (평) : "+ area2);



    }
}
