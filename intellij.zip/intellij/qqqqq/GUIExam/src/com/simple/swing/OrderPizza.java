package com.simple.swing;

import javax.imageio.stream.ImageInputStream;
import javax.swing.*;
import java.awt.*;

public class OrderPizza extends JFrame {
    private  int munuCombo;
    private  int munuPotato;
    private  int munuBulgoki;


    public OrderPizza (int munuCombo, int munuPotato, int munuBulgoki) {

        this.munuPotato = munuPotato;
        this.munuBulgoki = munuBulgoki;
        this.munuCombo = munuCombo;
    }

    public OrderPizza() throws HeadlessException {
        // 윈도우 생성에 필요한 설정

            setTitle("피자주문기");
            setSize(600, 150);


            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // setLayout(new FlowLayout());

        // 컴포넌트 생성
        JPanel panel = new JPanel();
        JPanel panelA = new JPanel();
        JPanel panelB = new JPanel();
        JPanel pricePanel = new JPanel();

        panel.setBackground(Color.gray);
        panelB.setBackground(Color.pink);

        JLabel label = new JLabel("자바 피자에 오신것을 환영합니다");
        JLabel comboPrice = new JLabel("5000원");
        JButton button1 = new JButton("콤보피자");
        JButton button2 = new JButton("포테이토피자");
        JButton button3 = new JButton("불고기피자");

        panelB.add(button1);
        panelB.add(button2);
        panelB.add(button3);
        panelA.add(label);

        panel.add(panelA);
        panel.add(panelB);

        this.add(button3,BorderLayout.NORTH);
        this.add(panelB,BorderLayout.CENTER);
        this.add(panelA,BorderLayout.SOUTH);

        // 윈도우 활성화
        setVisible(true);
    }

    public static void main(String[] args) {

        new OrderPizza(5000, 9000, 20000);
    }
}
