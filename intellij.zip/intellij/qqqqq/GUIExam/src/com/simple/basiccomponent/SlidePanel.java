package com.simple.basiccomponent;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;

public class SlidePanel extends JPanel implements ChangeListener {

    static final int INIT_VALUE = 15;
    private JButton button;
    private JButton buttonOk;
    private JSlider slider;

    public SlidePanel() {
        JPanel panel;

        panel = new JPanel();
        JLabel label = new JLabel("슬라이더를 움직여 보셈",JLabel.CENTER);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(label);

        // 슬라이더 생성 및 설정
        slider = new JSlider(0, 30,INIT_VALUE);
        slider.setMajorTickSpacing(10);
        slider.setMinorTickSpacing(1);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);

        slider.addChangeListener(this);
        panel.add(slider);

        button = new JButton("");
        ImageIcon icon = new ImageIcon("dog.gif");
        button.setIcon(icon);
        button.setSize(INIT_VALUE*10, INIT_VALUE*10);
        panel.add(button);
        add(panel);

    }

    @Override
    public void stateChanged(ChangeEvent e) {
        JSlider slider = (JSlider)e.getSource();
        if (!slider.getValueIsAdjusting()){
            int value = slider.getValue();
            button.setSize(value*10,value*10);


        }
    }
}
