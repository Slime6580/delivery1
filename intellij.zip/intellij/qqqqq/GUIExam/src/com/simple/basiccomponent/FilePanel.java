package com.simple.basiccomponent;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class FilePanel extends JPanel implements ActionListener {

    JFileChooser fc;
    JButton openButton, saveButton;

    public FilePanel() {

        fc = new JFileChooser();
        openButton = new JButton("파일 오픈");
        saveButton = new JButton("파일 저장");

        openButton.addActionListener(this);
        saveButton.addActionListener(this);

        // 컴포넌트 등록
        add(openButton);
        add(saveButton);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == openButton) {
            int returnVal = fc.showSaveDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION){
                File file = fc.getSelectedFile();
                System.out.println(file.toPath());
            }else {

            }
        }

        if (e.getSource() == saveButton){

        }
    }
}
