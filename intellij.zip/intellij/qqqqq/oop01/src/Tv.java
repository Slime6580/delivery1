
public class Tv {
    //상태, 속성
    int channel;
    int volume;
    boolean power;

    //동작, 행위
    // 전원관리, 채널관리, 볼륨관리

    public void power(){
        if(power){
        power = false; // 전원 on
        }else {
            power = true; // 전원
        }
    }

    public void changeChenel(int channel){
        this.channel = channel;
    }
    public void chenenlUP(){
        channel++;
    }
    public void chenenlDown(){
        channel--;
    }

    public int volumeUP(){
        return volume++;
    }
    public int volumeDown(){
        return volume--;
    }


}