package com.Simple.oop;

public class Divider {
    public int div(int num1, int num2) {
        return num1 / num2;
    }

    public  double divDouble(int num1, int num2){
        return (double) num1/num2;
    }
}
