package com.Simple.oop;

public class Subtract {
    public int sub(int num1, int num2) {
        return num1 - num2;
    }
}
