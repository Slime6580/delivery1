package com.Simple.oop;

public class Test {
    public static void main(String[] args) {
        Adder add = new Adder();
        int sum = add.add(10,20);
        System.out.println();
    }
}
