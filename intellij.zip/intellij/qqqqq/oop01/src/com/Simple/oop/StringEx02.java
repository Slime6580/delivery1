package com.Simple.oop;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Scanner;

public class StringEx02 {
    public static void main(String[] args) {
        // 주민번호 정보를 이용하여 성별과 나이를 출력하시오
        // ex > 111111-311111


        String code = "101-9949-2243";

        char Gcode = code.charAt(7); // 성별
        String num1 = code.substring(0, 2); // 출생년도
        LocalDateTime now = LocalDateTime.now();
        String []codes = code.split("-");

        System.out.println("code : "+codes[0]);
        System.out.println("code : "+codes[1]);
        System.out.println("code : "+codes[2]);
        for (String code1 : codes) {
            System.out.println("code : "+code1);
        }
        /*

        int currentYear = now.getYear();
        int age = 0;
        String gender = null;
        System.out.println(Gcode);
        System.out.println("출생년도 : "+num1);

        switch (Gcode){
            case '1' :
                gender="남";
                age = currentYear - (Integer.parseInt(num1)+1900);
                break;
            case '3' :
                gender="남";
                age = currentYear - (Integer.parseInt(num1)+2000);
                break;
            case '2' :
                gender="여";
                age = currentYear - (Integer.parseInt(num1)+1900);
                break;
            case '4' :
                gender="여";
                age = currentYear - (Integer.parseInt(num1)+2000);
                break;
            default:
                System.out.println("코드에러");
        }

        System.out.println("성별 : "+gender);
        System.out.println("나이 : "+age);
*/
        }
    }