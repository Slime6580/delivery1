package com.Simple.oop;

import java.util.Arrays;

public class StringEx {
    public static void main(String[] args) {

        char[] names = {'h', 'e', 'l', 'l', 'o'};
        String ait = null;
        System.out.println(names[0]);
        System.out.println(names.length);
        System.out.println(names);
        String str;
        str = Arrays.toString(names);
        str = null;
        String str2 = null;


        String name = "Hello Java";
        System.out.println(name.charAt(0));
        System.out.println(name.length());

        String name2 = new String("hello java");
        System.out.println(name2);
        System.out.println(name2);

        String name1 = name;
        str = str + "_홍길동 +ett";
        System.out.println(str);

        str2 = name2;
        System.out.println(str2.hashCode());
        System.out.println("str2 : " + str2);
        System.out.println("name 2 :" + name2);
        name2 = "Hello World";
        str2 = str2 + "_이순신";


    }
}
