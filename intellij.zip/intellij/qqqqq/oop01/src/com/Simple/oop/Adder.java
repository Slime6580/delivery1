package com.Simple.oop;

public class Adder {
    public  int add(int num1, int num2){
        return  num1+num2;
        }
    }