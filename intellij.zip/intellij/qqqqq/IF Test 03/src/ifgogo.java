public class ifgogo {
    public static void main(String[] args) {

        int x = 201;
        int y = 20;
        int result = x - y;

        if (result>0){
            System.out.println("x가 y보다 더 크다");
        }
        if (result<0) {
            System.out.println("x가 y보다 더 작다");
        }
        if (result==0) {
            System.out.println("x와 y의 숫자는 같다");
        }

    }
}
