import java.util.Scanner;

public class iftest04 {
    public static void main(String[] args) {

        // 학점 계산
        // n개의 조건을 처리 : if()~ else if()~ else

        // 입력 : 점수
        // 출력 : 평점 : A, B, C, D, E, F
        // 평점 기준 : A = 90점 이상, B = 90점 미만이고 80점 이상 ( 80<= B < 90 )

        int jumsu;

        Scanner input = new Scanner(System.in);
        System.out.println("점수 : ");
        String jumsu_ = input.nextLine();
        jumsu = Integer.parseInt(jumsu_);

        String grade = "";
        if(jumsu >= 90) {
            grade = "a";
        } else if (jumsu >=80) {
            grade = "B";
        } else if (jumsu >=70) {
            grade = "C";
        } else if (jumsu >=60) {
            grade = "D";
        } else if (jumsu >=50) {
            grade = "E";
        } if ( 50>jumsu && jumsu >=40) {
            grade = "F";
        }

        System.out.println("점수 :" +jumsu);
        System.out.println("학점 :" +grade);

    }
}
