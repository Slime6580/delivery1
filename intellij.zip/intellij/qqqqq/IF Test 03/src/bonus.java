import java.util.Scanner;

public class bonus {
    public static void main(String[] args) {

        int x = 1000; //실적 목표
        int y;  //달성한 실적

        Scanner input = new Scanner(System.in);
        System.out.println("이번 실적 :");
        String y_ = input.nextLine();
        y = Integer.parseInt(y_);

        int result =(y - x)/10; // 성과금
        if (x<y) {
            System.out.println("이번 실적은" + y + "입니다.");
            System.out.println("이번 성과급은" + result + "입니다");
        }
        if (x>=y) {
            System.out.println("실적 목표에 미치지 못하여 성과급이 지급되지 않습니다. \n 귀하의 전진을 기원합니다");
        }
    }
}
