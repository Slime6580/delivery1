import java.util.Scanner;

public class SwitchEx03 {
    public static void main(String[] args) {

        int age; //나이

        Scanner input = new Scanner(System.in);
        System.out.println("나이 :");
        String age1_ = input.nextLine();
        age = Integer.parseInt(age1_);

        System.out.println("대상자의 나이는"+age+"입니다");

        String result;

        if (0<age && age<=6) {
            result = "영유아";
            System.out.println("대상자는" +result+ "입니다.");
            System.out.println("요금은 0원입니다");
        }  else if (7<age && age<=12){
            result = "어린이";
            System.out.println("대상자는" +result+ "입니다.");
            System.out.println("요금은 350원입니다");
        }  else if (13<age && age<=18) {
            result = "청소년";
            System.out.println("대상자는" +result+ "입니다.");
            System.out.println("요금은 750원입니다");
        }  else if (19<age && age<=64) {
            result = "성년";
            System.out.println("대상자는" +result+ "입니다.");
            System.out.println("요금은 1250원입니다");
        }  else if (65<age && age<=100) {
            result = "노년";
            System.out.println("대상자는" +result+ "입니다.");
            System.out.println("요금은 0원입니다");
        }




    }
}
