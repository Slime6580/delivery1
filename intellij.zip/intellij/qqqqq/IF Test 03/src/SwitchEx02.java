import java.util.Scanner;

public class SwitchEx02 {
    public static void main(String[] args) {

        // 체질량지수 = 몸무게를 키의 제곱으로 나눈 값
        // ex) 키 170 몸무게 73kg = 73 / (1.7x1.7) = 체질량지수
        float num1; // 몸무게

        Scanner input = new Scanner(System.in);
        System.out.println("몸무게 :");
        String num1_ = input.nextLine();
        num1 = Integer.parseInt(num1_);

        float num2; // 키

        Scanner input2 = new Scanner(System.in);
        System.out.println("키 :");
        String num2_ = input2.nextLine();
        num2 = Integer.parseInt(num2_);

        float result1; // 키를 제곱근으로 나눈 값
        float result2; // bmi 지수

        result1 = (num2/100)*(num2/100);
        result2 = num1/result1;
        String grade = ""; // 판정

        System.out.println("당신의 bmi지수는 " +result2+ "입니다.");

        if (result2<=18.5){
            grade = "저체중";
        } else if (result2<=23){
            grade = "정상";
        } else if (result2<=25){
            grade = "과체중";
        } else if (result2<=30){
            grade = "비만";
        } else if (result2<=100){
            grade = "고도비만";
        }

        System.out.println("당신은 "+grade+"에 해당합니다.");

    }
}
