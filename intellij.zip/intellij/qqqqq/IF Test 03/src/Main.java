
public class Main {
    public static void main(String[] args) {

        //대소비교
        int x = 10;
        int y = 9;
        int result = x - y;
        // 비교 연산자. 비교문(if)
        if (x > y) {
            System.out.println("x가 큰수");
        } else {
            if (x < y) {
                System.out.println("x가 작다");
            } else {
                System.out.println("x가 작거나 같다");
            }

        }
    }
}