package hakaldan;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class CheckBoxItemEventEx extends JFrame {
    private JCheckBox[] achim = new JCheckBox[5];
    private String[] names = {"구운계란", "바나나", "닭가슴살(100g)","에너지바","미숫가루"};
    private JLabel sumLabel;

    public CheckBoxItemEventEx() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container c = getContentPane();
        c.setLayout(new FlowLayout());

        MyItemListener listener = new MyItemListener();

        for (int i = 0; i < achim.length; i++) {
            achim[i] = new JCheckBox(names[i]);
            achim[i].setBorderPainted(true);
            c.add(achim[i]);
            achim[i].addItemListener(listener);
        }
        sumLabel = new JLabel("준비중");
        c.add(sumLabel);
        setSize(350, 500);
        setVisible(true);
    }

    public class MyItemListener implements ItemListener {
        private int Calorie = 0; //칼로리
        private float Protein = 0; //단백질
        private float Carb = 0; //탄수화물
        private float Fat = 0; //지방

        public void itemStateChanged(ItemEvent e) {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                if (e.getItem() == achim[0]) {
                    Calorie += 270;
                    Protein += 5.57F;
                    Fat += 4.4F;
                    Carb += 0.34F;
                } else if (e.getItem() == achim[1]) {
                    Calorie += 440;
                    Protein += 1.29F;
                    Fat += 0.39F;
                    Carb += 26.95F;
                } else if (e.getItem() == achim[2]) {
                    Calorie += 458;
                    Protein += 22.98F;
                    Fat += 1.23F;
                } else if (e.getItem() == achim[3]) {
                    Calorie += 188;
                    Protein += 6;
                    Fat += 10;
                    Carb += 20;
                } else if (e.getItem() == achim[4]) {
                    Calorie += 140;
                    Protein += 5.29F;
                    Fat += 1;
                    Carb += 27.59F;
                }
            } else {
                if (e.getItem() == achim[0]) {
                    Calorie -= 270;
                    Protein -= 5.57F;
                    Fat -= 4.4F;
                    Carb -= 0.34F;
                } else if (e.getItem() == achim[1]) {
                    Calorie -= 440;
                    Protein -= 1.29F;
                    Fat -= 0.39F;
                    Carb -= 26.95F;
                } else if (e.getItem() == achim[2]) {
                    Calorie -= 458;
                    Protein -= 22.98F;
                    Fat -= 1.23F;
                } else if (e.getItem() == achim[3]) {
                    Calorie -= 188;
                    Protein -= 6;
                    Fat -= 10;
                    Carb -= 20;
                } else if (e.getItem() == achim[4]) {
                    Calorie -= 140;
                    Protein -= 5.29F;
                    Fat -= 1;
                    Carb -= 27.59F;
                }
            }
            sumLabel.setText("칼로리 :" + Calorie + "단백질" + Protein + "지방" + Fat + "탄수화물" + Carb);
        }
    }

    public static void main(String[] args) {
        new CheckBoxItemEventEx();
    }
}