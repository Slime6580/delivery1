package hakaldan;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class Jumsim extends JFrame {
    private JCheckBox[] Lunch = new JCheckBox[5];
    private String[] names = {"돼지국밥", "제육볶음", "햄버거", "짜장면", "순두부찌개"};
    private JLabel sumLabel;


    public Jumsim() {

        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        LunchCal lunchCal = new LunchCal();

        for (int i = 0; i < Lunch.length; i++) {
            Lunch[i] = new JCheckBox(names[i]);
            Lunch[i].setBorderPainted(true);
            c.add(Lunch[i]);
            Lunch[i].addItemListener(lunchCal);
        }
        sumLabel = new JLabel("준비중");
        c.add(sumLabel);

    }

    public JCheckBox[] getLunch() {
        return Lunch;
    }

    public void setLunch(JCheckBox[] lunch) {
        Lunch = lunch;
    }

    public class LunchCal implements ItemListener {
        private int Calorie = 0; //칼로리
        private float Protein = 0; //단백질
        private float Carb = 0; //탄수화물
        private float Fat = 0; //지방

        @Override
        public void itemStateChanged(ItemEvent e) {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                if (e.getItem() == Lunch[0]) {
                    Calorie += 270;
                    Protein += 5.57F;
                    Fat += 4.4F;
                    Carb += 0.34F;
                } else if (e.getItem() == Lunch[1]) {
                    Calorie += 440;
                    Protein += 1.29F;
                    Fat += 0.39F;
                    Carb += 26.95F;
                } else if (e.getItem() == Lunch[2]) {
                    Calorie += 458;
                    Protein += 22.98F;
                    Fat += 1.23F;
                } else if (e.getItem() == Lunch[3]) {
                    Calorie += 188;
                    Protein += 6;
                    Fat += 10;
                    Carb += 20;
                } else if (e.getItem() == Lunch[4]) {
                    Calorie += 140;
                    Protein += 5.29F;
                    Fat += 1;
                    Carb += 27.59F;
                } else {
                    if (e.getItem() == Lunch[0]) {
                        Calorie -= 270;
                        Protein -= 5.57F;
                        Fat -= 4.4F;
                        Carb -= 0.34F;
                    } else if (e.getItem() == Lunch[1]) {
                        Calorie -= 440;
                        Protein -= 1.29F;
                        Fat -= 0.39F;
                        Carb -= 26.95F;
                    } else if (e.getItem() == Lunch[2]) {
                        Calorie -= 458;
                        Protein -= 22.98F;
                        Fat -= 1.23F;
                    } else if (e.getItem() == Lunch[3]) {
                        Calorie -= 188;
                        Protein -= 6;
                        Fat -= 10;
                        Carb -= 20;
                    } else if (e.getItem() == Lunch[4]) {
                        Calorie -= 140;
                        Protein -= 5.29F;
                        Fat -= 1;
                        Carb -= 27.59F;
                    }
                    sumLabel.setText("칼로리 :" + Calorie + "단백질" + Protein + "지방" + Fat + "탄수화물" + Carb);
                }
            }
        }
    }
}
