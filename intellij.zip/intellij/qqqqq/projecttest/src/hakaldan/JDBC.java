package hakaldan;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;



public class JDBC
{
    Connection con; // 멤버변수
    Statement stmt;
    ResultSet rs;


    Customer c1;

    public JDBC()
    {
        c1=new Customer();
    }
    void JDBC() {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String userid =  "c##madang"; //c##추가
        String pwd = "c##madang"; //c##추가

        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("드라이버 로드 성공");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        try
        {
            System.out.println("데이터베이스 연결 준비 .....");
            con = DriverManager.getConnection(url,userid,pwd);
            System.out.println("데이터베이스 연결 성공");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    void printCustomer() //하는 일이 뭐냐?
    {
        String query = "SELECT custid, name, address, phone  FROM customer";
        try
        {
            stmt = con.createStatement(); //2
            rs = stmt.executeQuery(query); //3
            System.out.println("CUSTID \tNAME \tADDRESS \tPHONE");

            int i=0;
            while (rs.next ())
            {
                c1.custid=rs.getInt(1);
                c1.name=rs.getString(2);
                c1.address=rs.getString(3);
                c1.phone=rs.getString(4);
                printcust_obj();
            }
            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    void printcust_obj(){
        System.out.print(c1.custid+"\t");
        System.out.print(c1.name+"\t");
        System.out.print(c1.address+"\t");
        System.out.println(c1.phone+"\t");
    }

}