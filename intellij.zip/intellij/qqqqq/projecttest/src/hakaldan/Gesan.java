package hakaldan;
import javax.swing.*;
import java.awt.*;

public class Gesan extends JFrame {
    public Gesan() {
        CheckBoxItemEventEx cb = new CheckBoxItemEventEx();

        setTitle("밥은 잘 먹고 다니니?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ButtonGroup group = new ButtonGroup();
        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        class morning {

        }
        JRadioButton morning = new JRadioButton("아침");
        JRadioButton jumsim = new JRadioButton("점심");
        JRadioButton evening = new JRadioButton("저녁");
        JRadioButton gansick = new JRadioButton("간식");

        group.add(morning);
        group.add(jumsim);
        group.add(evening);
        group.add(gansick);

        c.add(morning);
        c.add(jumsim);
        c.add(evening);
        c.add(gansick);
        setSize(300, 500);
        setVisible(true);


    }


    public static void main(String[] args) {
        new Gesan();
    }
}
