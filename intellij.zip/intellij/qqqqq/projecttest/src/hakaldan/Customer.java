package hakaldan;

public class Customer {
    int custid;
    String name;
    String address;
    String phone;
}
