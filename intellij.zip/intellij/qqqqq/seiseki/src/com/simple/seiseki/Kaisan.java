package com.simple.seiseki;

import java.util.Random;
import java.util.Scanner;

public class Kaisan {

    Scanner kbd = new Scanner(System.in);
    Random random = new Random();



    String Name = kbd.nextLine();
    System.out.println("이름을 입력 : ");



    String hakbun = kbd.nextLine();
    System.out.println("학번을 입력 : ");




    int gukugo = random.nextInt(100);
    int eigo = random.nextInt(100);
    int suigaku = random.nextInt(100);

    int sum = gukugo + eigo + suigaku;
    double ave = sum / 3;

    char gender;

    public static char getGrade(double ave) {
        char grade = 'f';

        if (ave >= 90.0) {
            grade = 'A';
        } else if (ave >= 80) {
            grade = 'B';
        } else if (ave >= 70) {
            grade = 'B';
        } else if (ave >= 60) {
            grade = 'C';
        } else if (ave >= 50) {
            grade = 'D';
        }
        return grade;
    }
}

