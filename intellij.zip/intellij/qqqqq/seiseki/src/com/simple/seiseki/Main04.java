package com.simple.seiseki;

import java.util.Scanner;

public class Main04 {

    final static int SUBJECT_COUNT = 3;

    public static void main(String[] args) {
        // 입력: 이름, 성별, 학번, 국어, 영어, 수학, 남학생의 평균, 여학생의 평균, 남녀 인원수
        String name;
        boolean gender;
        String gender_;
        String code;
        int kor, eng, mat;
        int korSum = 0, engSum = 0, matSum = 0 ;
        int count = 0;
        int total;
        double avg, korAvg, engAvg, matAvg;
        char grade;

        int mkor=0, meng=0, mmat=0; //남학생 각 과목 총점
        int fkor=0, feng=0, fmat=0; //여학생 각 과목 총점

        int male = 0;
        int female = 0;
        int mSum=0, fSum=0; // 남녀 총점 비교
        double maleAvg, femaleAvg; // 남녀 평균

        Scanner kbd = new Scanner(System.in);
        System.out.println("--------- 성적표 ---------");
        System.out.println("이름 성별 학번 국어  영어  수학  총점  평균");

        int i;
        for (i = 0; i < 3; i++) {

            System.out.print("이름 :");
            name = kbd.nextLine();

            System.out.print("m or f :");
            gender_ = kbd.nextLine();
            if (gender_.equals("m")){
                gender = true;
                gender_ = "남";
                male++;
            } else {
                gender = false;
                gender_ = "여";
                female++;
            }

            System.out.print("학번 :");
            code = kbd.nextLine();

            System.out.print("국어 :");
            kor = Integer.parseInt(kbd.nextLine());
            fkor += kor;
            // if (gender == true) {mkor += kor;}

            System.out.print("영어 :");
            eng = Integer.parseInt(kbd.nextLine());

            System.out.print("수학 :");
            mat = Integer.parseInt(kbd.nextLine());

            // 처리: 총점, 평균, 과목별 평균
            // 총점=국어+영어+수학
            // 평균=총점/과목수
            // grade = A, B, C, D, F
            // 과목별 평균 = 과목총점 (korSum) / 데이터 수(count)
            total = getTotal(kor, eng, mat);

            // total = kor+eng+mat;
            avg = getAvg(total);
            grade = getGrade(avg);

            //과목별 총점
            korSum += kor;
            engSum += eng;
            matSum += mat;

            mSum +=
            count++;

            // 출력
            System.out.printf("%s %s %s %4d %4d %4d %4d %6.2f %c\n",
                    name, gender_, code, kor, eng, mat, total, avg, grade);

            //int total = kor + eng + mat;

        }
        korAvg = (double) korSum / count;
        engAvg = (double) engSum / count;
        matAvg = (double) matSum / count;
        System.out.println("과목별 평균");
        System.out.println("국어평균 : " + korAvg);
        System.out.println("영어평균 : " + engAvg);
        System.out.println("수학평균 : " + matAvg);

        //남녀 평균
        maleAvg = mSum/male;
        femaleAvg = fSum/female;
        System.out.println("남자 인원수 : " +male);
        System.out.println("여자 인원수 : " +female);
        System.out.println("남학생 국어 총점 : "+mkor);
        //System.out.println("남자 학생의 평균 : "+maleAvg);
        //System.out.println("여자 학생의 평균 : "+femaleAvg);
    }

    private static int getTotal(int kor, int eng, int mat) {
        return kor + eng + mat;
    }

    private static double getAvg(int tot) {
        return (double) tot / SUBJECT_COUNT;


    }

    private static char getGrade(double avg) {
        char grade = 'F';

        if (avg >= 90.0) {
            grade = 'A';
        } else if (avg >= 80) {
            grade = 'B';
        } else if (avg >= 70) {
            grade = 'B';
        } else if (avg >= 60) {
            grade = 'C';
        } else if (avg >= 50) {
            grade = 'D';
        }
        return grade;
    }
}