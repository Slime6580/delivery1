package com.simple.seiseki;

import javax.naming.Name;

public class Test {
    public static void main(String[] args) {

        Kaisan kaisan = new Kaisan();

        for (int i = 0; i < 3; i++) {
            System.out.println("학생 이름 : " + kaisan.Name);
            System.out.println("학생 학번 : " + kaisan.hakbun);
            System.out.println("국어 점수 : " + kaisan.gukugo);
            System.out.println("수학 점수 : " + kaisan.suigaku);
            System.out.println("영어 점수 : " + kaisan.eigo);
            System.out.println("총점 : " + kaisan.sum);
            System.out.println("평점 : " + kaisan.ave);
            System.out.println("학점 : ");
        }
    }
}

