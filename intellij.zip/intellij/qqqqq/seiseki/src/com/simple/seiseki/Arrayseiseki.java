package com.simple.seiseki;

import java.util.Scanner;

public class Arrayseiseki {
    public static void main(String[] args) {

        System.out.println("데이터의 갯수는 ? ");
        Scanner kbd = new Scanner(System.in);

        int size = kbd.nextInt();

        // 요청한 크기만큼 배열을 준비
        String[][] jumsu = new String[size][5];

        jumsu[0][0] = "사소리";
        jumsu[0][1] = "80";
        jumsu[0][2] = "75";
        jumsu[0][3] = "90";
        jumsu[0][4] = "1"; // 1 = 남자
        jumsu[1][0] = "오오카미";
        jumsu[1][1] = "60";
        jumsu[1][2] = "20";
        jumsu[1][3] = "50";
        jumsu[1][4] = "2"; // 2 = 여자
        jumsu[2][0] = "시카";
        jumsu[2][1] = "45";
        jumsu[2][2] = "88";
        jumsu[2][3] = "99";
        jumsu[2][4] = "1";

        int Ksum = 0; // 총점
        int Esum = 0;
        int Msum = 0;

        int Ssum = 0; // 개인 총점
        int Osum = 0;
        int Asum = 0;

        int Alm = 0; // 성별 숫자
        int Alf = 0;

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(jumsu[i][j] + " ");
            }
            Ksum += Integer.parseInt(jumsu[i][1]);
            Esum += Integer.parseInt(jumsu[i][2]);
            Msum += Integer.parseInt(jumsu[i][3]);
            int gender = Integer.parseInt(jumsu[i][4]);

            if (gender == 1) {
                Alm++;

            } else if (gender == 2) {
                Alf++;

            }

            System.out.println();
        }
        //모든 과목의 총점과 평균을 출력
        //과목별 총점 변수

        for (int k = 1; k < 4; k++) {
            Ssum += Integer.parseInt(jumsu[0][k]);
            Osum += Integer.parseInt(jumsu[1][k]);
            Asum += Integer.parseInt(jumsu[2][k]);
        }

        double Mavg = (double) Msum / size;  // 평균
        double Kavg = (double) Ksum / size;
        double Eavg = (double) Esum / size;

        double Savg = (double) Ssum / size;
        double Oavg = (double) Osum / size;
        double Aavg = (double) Asum / size;



        System.out.println("국어 총점 : " + Ksum);
        System.out.println("국어 평균 : " + Kavg);

        System.out.println("영어 총점 : " + Esum);
        System.out.println("영어 평균 : " + Eavg);

        System.out.println("수학 총점 : " + Msum);
        System.out.println("수학 평균 : " + Mavg);

        System.out.println("사소리의 총점 : " + Ssum);
        System.out.println("사소리의 평균 : " + Savg);

        System.out.println("오오카미의 총점 : " + Osum);
        System.out.println("오오카미의 평균 : " + Oavg);

        System.out.println("시카의 총점 : " + Asum);
        System.out.println("시카의 평균 : " + Aavg);

        System.out.println("총 남자의 수 :" + Alm);
        System.out.println("총 여자의 수 :" + Alf);


        double avg = Savg;

            char grade = 'F';

            if (avg >= 90.0) {
                grade = 'A';
            } else if (avg >= 80) {
                grade = 'B';
            } else if (avg >= 70) {
                grade = 'C';
            } else if (avg >= 60) {
                grade = 'D';
            } else if (avg >= 50) {
                grade = 'E';
            }

        System.out.println("학점 : "+grade);
        }
    }


