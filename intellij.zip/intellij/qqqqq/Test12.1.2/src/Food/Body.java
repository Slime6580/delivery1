package Food;

public class Body {
    public static void main(String[] args) {

        Food.condition();

        HotchickenNoodle h = new HotchickenNoodle();
        h.eat();
        h.recharge();

        SandWitch s = new SandWitch();
        s.eat();
        s.recharge();

    }
}
