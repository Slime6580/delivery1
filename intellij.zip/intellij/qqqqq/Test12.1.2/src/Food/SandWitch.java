package Food;

public class SandWitch extends Food{

    @Override
    public void eat() {
        calorie = 1056;
        carb = 27;
        protein = 8;
        fat = 12;
        System.out.println("샌드윗치를 섭취");
    }

    @Override
    public void recharge() {
        System.out.println(calorie+"만큼의 칼로리를 흡수");
        System.out.println("칼로리 외 영양소");
        System.out.println("탄수화물 : "+carb);
        System.out.println("단백질 : "+protein);
        System.out.println("지방 : "+fat);
    }

}
