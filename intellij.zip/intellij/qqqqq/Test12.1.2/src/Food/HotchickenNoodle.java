package Food;

public class HotchickenNoodle extends Food{

    @Override
    public void eat() {
        calorie = 2218;
        carb = 85;
        protein = 12;
        fat = 16;
        System.out.println("불닭볶음면을 섭취");
    }

    @Override
    public void recharge() {
        System.out.println(calorie+"만큼의 칼로리를 흡수");
        System.out.println("칼로리 외 영양소");
        System.out.println("탄수화물 : "+carb);
        System.out.println("단백질 : "+protein);
        System.out.println("지방 : "+fat);
    }
}
