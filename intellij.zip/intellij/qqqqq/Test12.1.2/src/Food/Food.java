package Food;

public class Food {
    public int calorie;
    public int protein;
    public int fat;
    public int carb;

    public Food(){

    }

    public void eat() {
        System.out.println("음식을 먹는다");
    }
    public void recharge() {
        System.out.println("에너지를 흡수");
    }

    public static void condition() {
        System.out.println("현재 몸 상태를 표시합니다");
    }
}

