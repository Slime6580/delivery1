import java.util.Scanner;

public class TestAn1 {
    public static void main(String[] args) {
        Scanner kbd = new Scanner(System.in);
        int [] number = new int[kbd.nextInt()];
        for (int i = 0; i <number.length; i++) {
            number[i] = kbd.nextInt();
            System.out.println(i + " 번째 값 : "+number[i]);
        }
        System.out.print("배열에 저장된 값 : ");
        for (int i = 0; i <number.length; i++)
            System.out.print(number[i]+" ");

        int max = Integer.MIN_VALUE;

        for (int i = 0; i<number.length; i++) {
            if (number[i] > max)
                max = number[i];
        }
        System.out.println();
        System.out.println("최대값 : "+max);

        int sum = 0;
        int count = 0;
        System.out.print("배열에 저장된 짝수 : ");

        for (int i = 0; i<number.length; i++) {
            if (number[i] % 2 == 0) {
                sum += number[i];
                count++;
                System.out.print(number[i]+" ");
            }
        }
        System.out.println();
        System.out.println("짝수를 다 더한 값 : "+sum);

        float avg = (float) sum /count;

        System.out.println("평균 값 : "+avg);




    }
}
