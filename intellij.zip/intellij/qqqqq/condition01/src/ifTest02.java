import java.util.Scanner;

public class ifTest02 {
    public static void main(String[] args) {
        // 입력 : 생년월일(태어난 년도)
        // 출력 : 성년 / 미성년
        // 성년 : 20세 이상

        int num1 ;//num1 이번년도
        int num2 ; //num2 생년
        Scanner input = new Scanner(System.in);
        System.out.println("출생년도 :");
        String num1_ = input.nextLine();
        num1 = Integer.parseInt(num1_);

        Scanner input = new Scanner(System.in);
        System.out.println("현재년도 :");
        String num2_ = input.nextLine();
        num1 = Integer.parseInt(num2_);

        int age = num1 - num2;

        String result = "성년";

        if(age<20) {
            result = "미성년";
        }
        System.out.println("이번년도 :"+num2);
        System.out.println("대상자 생년 : "+num1);
        System.out.println("결과 : "+result);

        System.out.println(num1+"년 출생자는 "+result+"입니다");

    }
}
