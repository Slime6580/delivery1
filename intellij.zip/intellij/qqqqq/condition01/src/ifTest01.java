public class ifTest01 {
    public static void main(String[] args) {
        // 입력 : 생년월일(태어난 년도)
        // 출력 : 성년 / 미성년
        // 성년 : 20세 이상

        int num;

        String result = "성년";

        num = 2003;

        if (num>2003) {
            result = "미성년";
        }

        System.out.println("생년 : "+num);
        System.out.println("결과 : "+result);
    }
}
