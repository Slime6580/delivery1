
public class Main {
    public static void main(String[] args) {

        if(args.length >0){
            for (int i = 0; i <args.length; i++) {
                System.out.println(" "+args[1]);
            }
        } if (args[0] == ("-h")){
            System.out.println("help");
        } else {
            System.out.println("no parameter");
        }

    }
}