public class Test {
    public static void main(String[] args) {

        int x = 10;
        int y = 20;
        int num;
        int z = y+num;

        System.out.println("x is "+ x);
        System.out.println("y is "+ y);
        System.out.println("z is "+ z);

    }
}
