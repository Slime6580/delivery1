import javax.xml.transform.stream.StreamSource;
import java.sql.SQLOutput;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        char char1 = '가';
        char char2 = '\uac00';
        boolean gender = true;

        boolean you_no = 2>3;

        System.out.println(char1+1);
        System.out.println(char2+20);


        System.out.println("\"나는 집에 가고 싶다\"");

        }
    }