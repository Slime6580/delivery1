import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String[] args) throws ParseException {

        Date now = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");

        System.out.println(now+"now");
        System.out.println(format+"format");




    }
}
