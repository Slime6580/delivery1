package com.simple.collection;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListEx {

    public static void main(String[] args) {
        //ArrayList<String> list = new ArrayList<>();
        LinkedList<String> list = new LinkedList<>();
        list.add("토스트");
        list.add("커피");
        list.add("베이컨");
        System.out.println("배열크기 :"+list.size());
        System.out.println(list);
        list.add(1,"계란후라이");
        System.out.println("배열크기 :"+list.size());
        System.out.println(list);
        list.set(2,"오렌지주스");
        System.out.println(list.get(3));
        list.remove(3);
        for (int i=0; i<list.size(); i++){
            System.out.print(list.get(i)+",");
        }
        for (String item: list){
            System.out.println(" "+item);
        }
        // 반복자를 이용한 list 출력

    }

}
