package com.simple.collection;

import java.util.HashMap;
import java.util.Map;

class Student {
    int number;
    String name;

    public Student(int number, String name) {
        this.number = number;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{" +
                "number=" + number +
                ", name='" + name + '\'' +
                '}';
    }
}

public class MapEx {

    public static void main(String[] args) {

        Map<String, Student> student = new HashMap<>();

         student.put("20090001",new Student(20090001,"스이"));
         student.put("20090002",new Student(20090002,"미코"));
         student.put("20090003",new Student(20090003,"아쿠아"));

        System.out.println(student);
        student.remove("20090002");
        System.out.println(student);
        student.put("20090003", new Student(20090003, "아쿠아"));
        System.out.println(student.get("20090001"));
        for (Map.Entry<String,Student> s : student.entrySet()){
            String key = s.getKey();
        }
    }
}
