package com.simple.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionMethood {
    public static void main(String[] args) {
        String[] sample = {"i","walk","the","line"};
        List<String> list = Arrays.asList(sample);
        int key = 5;
        List<Integer> listNum = new ArrayList<>();
        for(int i=0; i<10; i++) {
        int num = (int)(Math.random()*10);
        listNum.add(num);
        }
        int index = Collections.binarySearch(listNum,key);
        System.out.println("위치:"+index);
    }
}
