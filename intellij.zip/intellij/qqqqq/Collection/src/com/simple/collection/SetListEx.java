package com.simple.collection;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;

public class SetListEx {

    public static void main(String[] args) {
        LinkedHashSet<String> list = new LinkedHashSet<>();
        list.add("토스트");
        list.add("커피");
        list.add("베이컨");
        list.add("버터");
        list.add("베이컨");
        list.add("버터");

        System.out.println("배열크기 :"+list.size());
        System.out.println(list);

        // 반복자를 이용한 list 출력

    }

}
