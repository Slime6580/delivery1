package com.simple.genenic;

public class SimplePairTest {
    public static void main(String[] args) {
        SimplePair<String> pair = new SimplePair<String>("apple", "tomato");
        String data = pair.getData1();

        pair.setFirst("오렌지");

        SimplePair<Integer> ipair = new SimplePair<Integer>(10, 20);
        ipair.getData1();


    }
}
