import java.sql.SQLOutput;

public class Calculatormathhod {


    public static void main(String[] args) {

        // 필요한 재료
        // 숫자가 데이터
        int num1, num2;
        int add;
        int dub;
        int mul;
        float div;
        String name= "홍길동";

        int num3 = adder(20,30);
        num1 = 7;
        num2 = 3;

        // 필요한 기능
        // 사칙연산,...
        add = adder(num1,num2);//num1 + num2;
        dub = subtractor(num1,num2);
        mul = mulipler(num1,num2);
        div = divider(num1,num2); //(float)
        // 사칙연산 결과 출력
//        System.out.println("계산 결과");
//        System.out.println("숫자1: "+num1);
//        System.out.println("숫자2: "+num2);
//        System.out.println("덧셈결과: "+result);

        System.out.println( "결과 : "+num1+" + "+num2+" = "+add);
        System.out.println( "결과 : "+num1+" - "+num2+" = "+dub);
        System.out.println( "결과 : "+num1+" x "+num2+" = "+mul);
        System.out.println( "결과 : "+num1+" / "+num2+" = "+div);
        System.out.println( num3);
    }

    private static float divider(float num1, float num2) {
        float result = num1/num2;
        return result;}

    private static int mulipler(int num1, int num2) {
        int result = num1*num2;
        return  result;}

    private static int subtractor(int num1, int num2) {
        int result = num1-num2;
        return result;}

    private static int adder(int num1, int num2) {
        int result = num1+num2;
        return result;

    }
}
