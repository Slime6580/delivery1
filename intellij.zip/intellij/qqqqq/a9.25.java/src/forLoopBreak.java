public class forLoopBreak {
    public static void main(String[] args) {

        int num=0;
        for (int i=0; i<10; i++){
            for (int j=0; j<10; j++){
                num++;
                if (num == 50) break;
                System.out.print(num + " ");
            }
            if (num == 50) break;
            System.out.println();

        }
    }
}
