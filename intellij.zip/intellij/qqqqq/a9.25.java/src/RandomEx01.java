import java.util.Random;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class RandomEx01 {
    public static void main(String[] args) {

        // 난수 객체 생성
        Random generator = new Random();
        int sum = 0;
        int randomNumber;
        int max=10;
        int min=5;
        int range = max-min;
        for (int i = 0 ; i<30; i++){
        randomNumber = (int) (Math.random()*range)+5;
            System.out.println(randomNumber);

        }

    }
}