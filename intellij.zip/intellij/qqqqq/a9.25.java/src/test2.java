import java.util.Scanner;

public class test2 {
    public static void main(String[] args) {

        // 입력 : 이름 , 작업시간 , 시간당 급여

        int pay = 4500; // 시간당 급여
        int time; // 근무시간

        Scanner kbd1 = new Scanner(System.in);
        System.out.print("근무시간 : ");
        String time_ = kbd1.nextLine();
        time = Integer.parseInt(time_);
        int limt = 50; // 초과시간을 넘지않는 근무 최대 시간
        int result = (time-limt);

         // int num1; 공제액 = 총급여액의 3%
         // real; 실지급액 = 총급여액 - 공제액


        System.out.println("이름 : 홍길동");
        System.out.println("근무시간 : " + time);
        System.out.println("시간당 급여 : " + pay);
        
        if(time<=limt){
            double all = (time*pay);
            double num1 = (int)(all/(100/3));
            double real = (int)(all-num1);
            System.out.println("총 수당 : "+all);
            System.out.println("공제액 : " +num1);
            System.out.println("실지급액 : "+real);
        }

        else if (time>limt) {
            double more = (result) * pay * 1.5; // 초과수당 시간당 1.5배의 급여
            double all = (more+(50*4500));// 총급여액 \ 일한시간 x 시간당 급여
            double num1 = (int)(all/(100/3));
            double real = (int)(all - num1);

            System.out.println("초과한 근무 시간 : " +result);
            System.out.println("초과수당 " +more);
            System.out.println("총 수당 : "+all);
            System.out.println("공제액 : " +num1);
            System.out.println("실지급액 : "+real);
        }

    }
}
