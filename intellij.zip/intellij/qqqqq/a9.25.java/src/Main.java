import java.util.Random;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        // 난수 객체 생성
        Random generator = new Random();
        int sum = 0;
        int randomNumber;
        for (int i = 0 ; i<6; i++){
        randomNumber = (int)(1+generator.nextDouble()*4)+1;
            System.out.println(randomNumber);
        }

    }
}