import java.util.Random;
import java.util.Scanner;

public class test1 {
    public static void main(String[] args) {

        Random generator = new Random();
        int randomNumber = 0;
        int max=100;
        int min=1;
        int range = max-min;
        for (int i = 0 ; i<1; i++){
            randomNumber = (int) (Math.random()*range);
            System.out.println(randomNumber);
        }

        {
            int num;
            Scanner kbd1 = new Scanner(System.in);
            System.out.print("숫자 : ");
            String num_ = kbd1.nextLine();
            num = Integer.parseInt(num_);


            if (randomNumber > num) {
                System.out.println("정답보다 제시한 정수가 낮습니다");


            } else if (randomNumber < num) {
                System.out.println("정답보다 제시한 정수가 큽니다");


            }

            else if (randomNumber == num) {
                System.out.println("정답과 일치합니다");

            }
        }
        System.out.println("축하합니다");
    }
}
