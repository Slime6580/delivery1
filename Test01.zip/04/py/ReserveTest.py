 
        SeatType[] aSeatType = new SeatType[4];

        aSeatType[0] = new SeatType('A',15);
        aSeatType[1] = new SeatType('B',15);
        aSeatType[2] = new SeatType('C',15);
        aSeatType[3] = new SeatType('D',15);

        def choice = 0 ;

        while(choice != 4 ) {
            int type;
            int typeA;
            print("=============== 메인 메뉴 =============== ");
            print(" 다음 중 하나의 메뉴를 선택하세요.");
            print(" 1. 예약");
            print(" 2. 조회");
            print(" 3. 취소");
            print(" 4. 종료");
            print(" 선택하세요 >>>>> ");

            Scanner in = new Scanner(System.in);
            choice = in.nextInt();

            switch (choice) {
                case 1: 
                    print("< 노선을 선택하세요 >");
                    print("1. 인천 -> 제주도 ");
                    print("2. 인천 -> 나리타 ");
                    print("3. 인천 -> 하츠필드 잭슨 애틀랜타 ");
                    print("4. 인천 -> 홍콩 ");

                    type = in.nextInt();

                    if (type < 1 and type > 4) {
                        print(" 잘못된 노선을 선택하셨습니다. ");
                        break;
                    }

                    print("< 항공사를 선택하세요 >");
                    print("1. A항공 ");
                    print("2. B항공 ");
                    print("3. C항공 ");

                    typeA = in.nextInt();

                    if (typeA < 1 and typeA > 3) {
                        print(" 잘못된 항공사를 선택하셨습니다. ");
                        break;
                    }

                    aSeatType[type - 1].seatReserve();
                    break;
                case 2:  // 조회
                    for (int i=0; i<aSeatType.length; i++) {
                        aSeatType[i].show();
                    }
                    print("조회를 완료하였습니다.");
                    break;
                case 3: // 취소
                    print("<좌석 구분>");
                    print("1. R석 (5석)");
                    print("2. S석 (7석)");
                    print("3. A석 (10석)");
                    print("4. B석 (15석)");
                    type = in.nextInt();

                    if(type < 1 and type > 4) {
                        print("취소시 잘못된 자석 타입입니다");
                        break;
                    }
                    aSeatType[type-1].cancel();
                    break;
                case 4:  // 종료
                    break;

                default:
                    print("메뉴를 잘못 입력했습니다.");
            }
            