package Yoyaku;

import java.util.*;

public class ReserveTest extends Seat {

    public static void main(String[] args) {
        SeatType[] aSeatType = new SeatType[4];

        aSeatType[0] = new SeatType("인천 -> 제주도",15);
        aSeatType[1] = new SeatType("인천 -> 나리타",15);
        aSeatType[2] = new SeatType("인천 -> 하츠필드 잭슨 애틀랜타",15);
        aSeatType[3] = new SeatType("인천 -> 홍콩",15);

        int choice = 0 ;

        while(choice != 4 ) {
            int type;
            int typeA;
            System.out.println("=============== 메인 메뉴 =============== ");
            System.out.println(" 다음 중 하나의 메뉴를 선택하세요.");
            System.out.println(" 1. 예약");
            System.out.println(" 2. 조회");
            System.out.println(" 3. 취소");
            System.out.println(" 4. 종료");
            System.out.println(" 선택하세요 >>>>> ");

            Scanner in = new Scanner(System.in);
            choice = in.nextInt();

            switch (choice) {
                case 1: // 예약
                    System.out.println("< 노선을 선택하세요 >");
                    System.out.println("1. 인천 -> 제주도 ");
                    System.out.println("2. 인천 -> 나리타 ");
                    System.out.println("3. 인천 -> 하츠필드 잭슨 애틀랜타 ");
                    System.out.println("4. 인천 -> 홍콩 ");

                    type = in.nextInt();

                    if (type < 1 || type > 4) {
                        System.out.println(" 잘못된 노선을 선택하셨습니다. ");
                        break;
                    }

                    System.out.println("< 항공사를 선택하세요 >");
                    System.out.println("1. A항공 ");
                    System.out.println("2. B항공 ");
                    System.out.println("3. C항공 ");

                    typeA = in.nextInt();

                    if (typeA < 1 || typeA > 3) {
                        System.out.println(" 잘못된 항공사를 선택하셨습니다. ");
                        break;
                    }

                    aSeatType[type - 1].seatReserve();
                    break;
                case 2:  // 조회
                    for (int i=0; i<aSeatType.length; i++) {
                        aSeatType[i].show();
                    }
                    System.out.println("조회를 완료하였습니다.");
                    break;
                case 3: // 취소
                    System.out.println("<좌석 구분>");
                    System.out.println("1. R석 (15석)");
                    System.out.println("2. S석 (15석)");
                    System.out.println("3. A석 (15석)");
                    System.out.println("4. B석 (15석)");
                    type = in.nextInt();

                    if(type < 1 || type > 4) {
                        System.out.println("취소시 잘못된 자석 타입입니다");
                        break;
                    }
                    aSeatType[type-1].cancel();
                    break;
                case 4:  // 종료
                    break;

                default:
                    System.out.println("메뉴를 잘못 입력했습니다.");
            }
        }
    }
}