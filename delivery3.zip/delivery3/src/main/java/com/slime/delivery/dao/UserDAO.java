package com.slime.delivery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.slime.delivery.uservo.UserVO;

@Repository
public class UserDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	private final String INSERT_USER = "INSERT INTO users VALUE (?,?,?,?,?);";
	private final String USER_GET = "SELECT * FROM users where ID=? AND PW=?";
	
	public UserDAO() {
		System.out.println("UserDAO 지나가요");
	}
	
	
	public void insertUser(UserVO vo) {
		
		System.out.println("insertUserDAO");
		System.out.println(vo+"DAOVO");
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(INSERT_USER);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPw());
			pstmt.setString(3, vo.getNickName());
			pstmt.setString(4, vo.getDestination());
			pstmt.setString(5, vo.getPhoneNum());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}
	
	public UserVO getUser(UserVO vo) {
		UserVO user = null;
		System.out.println(USER_GET);
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(USER_GET);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPw());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user = new UserVO();
				user.setId(rs.getString("ID"));
				user.setPw(rs.getString("PW"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return user;
	}
	
	
}
