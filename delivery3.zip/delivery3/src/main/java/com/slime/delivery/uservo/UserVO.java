package com.slime.delivery.uservo;

public class UserVO {

	private String id;
	private String pw;
	private String nickName;
	private String destination;
	private String phoneNum;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	@Override
	public String toString() {
		return "UserVO [id=" + id + ", pw=" + pw + ", nickName=" + nickName + ", destination=" + destination
				+ ", phoneNum=" + phoneNum + "]";
	}



	
	
}
