package com.slime.delivery.service;

import com.slime.delivery.uservo.UserVO;

public interface UserService  {

	void insertUser(UserVO vo);
	
}
