package com.slime.delivery.service;

import java.util.List;

import com.slime.delivery.vo.DeliveryVO;

public interface DeliveryService {

	List<DeliveryVO> deliveryList(DeliveryVO vo); // brand.jsp 브랜드 페이지
	
	List<DeliveryVO> menuList(String brandName); // menuList 가져오기
	
	List<DeliveryVO> sideList(String brandName); // sideList
	
}
