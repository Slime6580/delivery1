package com.slime.delivery.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.slime.delivery.service.DeliveryService;
import com.slime.delivery.vo.DeliveryVO;

@Controller
@SessionAttributes("delivery")
public class DeliveryController {

	@Autowired
	DeliveryService deliveryService;

	@RequestMapping("/brand.do")
	public String getDeliveryList(DeliveryVO vo, Model model) {

		System.out.println("컨트롤러 통과");

		List<DeliveryVO> list = deliveryService.deliveryList(vo);

		model.addAttribute("deliveryList", list);

		return "brand.jsp";

	}

	@RequestMapping("/menu.do")
	public String getBrandName(@RequestParam("brandName") String brandName, Model model) {
		// String brandName="노랑 통닭";
		System.out.println(brandName);
		System.out.println("요청");
		List<DeliveryVO> list = deliveryService.menuList(brandName);
		System.out.println(list + " = list");
		model.addAttribute("menuList", list);

		return "brandmenu.jsp";
	}

	@RequestMapping("/cart.do")
	public String getSideList(@RequestParam("brandName") String brandName, Model model) {
	
		System.out.println(brandName);
		System.out.println("사이드 요청");
		List<DeliveryVO> slist = deliveryService.sideList(brandName);
		System.out.println(slist + " = slist");
		model.addAttribute("sideList", slist);

		return "cart.jsp";
	}
	
	@RequestMapping("/destination.do")
	public String insertOrder(@RequestParam("destination")String destination,
			@RequestParam("pNum")String pNum, Model model) {
		
		System.out.println(destination+"배달지");
		System.out.println(pNum+"핸드폰 번호");
		
		
		
		return "order.jsp";
		
	}
	
	
}
