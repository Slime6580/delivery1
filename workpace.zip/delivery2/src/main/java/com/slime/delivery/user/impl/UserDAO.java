package com.slime.delivery.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.slime.delivery.dao.JDBCUtil;
import com.slime.delivery.user.UserVO;

@Repository
public class UserDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	private String USER_GET = "SELECT * FROM USERS WHERE ID=? AND PASSWORD=?";

	private String INSERT_MEM = "INSERT INTO USERS VALUE (?,?,?);";
	
	public UserVO getUser(UserVO vo) {
		UserVO user = null;
		System.out.println(USER_GET);

		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(USER_GET);
			pstmt.setString(1, vo.getUserId());
			pstmt.setString(2, vo.getUserPw());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				user = new UserVO();
				user.setUserId(rs.getString("USERID"));
				user.setUserPw(rs.getString("USERPW"));
				user.setDeLocation(rs.getString("DELOCATION"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}

		return user;

	}

	public void insertMembership(UserVO vo) {
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(INSERT_MEM);
			pstmt.setString(1, vo.getUserId());
			pstmt.setString(2, vo.getUserPw());
			pstmt.setString(3, vo.getDeLocation());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
		
	}
	
}
