package com.slime.delivery.user;

public class UserVO {

	private String userId;
	private String userPw;
	private String deLocation;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getDeLocation() {
		return deLocation;
	}
	public void setDeLocation(String deLocation) {
		this.deLocation = deLocation;
	}
	
	@Override
	public String toString() {
		return "UserVO [userId=" + userId + ", userPw=" + userPw + ", deLocation=" + deLocation + "]";
	}
	
	
	
	
}
