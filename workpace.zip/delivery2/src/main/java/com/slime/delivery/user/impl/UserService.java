package com.slime.delivery.user.impl;

import com.slime.delivery.user.UserVO;

public interface UserService {

	UserVO getUser(UserVO vo);
	
	void insertMembership(UserVO vo);
	
}
