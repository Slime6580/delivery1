package com.slime.delivery.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.slime.delivery.dao.UserDAO;
import com.slime.delivery.service.UserService;
import com.slime.delivery.uservo.UserVO;

@Controller
@SessionAttributes("user")
public class UserController {

	@Autowired
	UserService userService;
	
	@RequestMapping("/insertUser.do")
	public String insertUser(UserVO vo, UserDAO userDAO) throws IllegalStateException, IOException {
		
		System.out.println("insert 유저 컨트롤러");
		System.out.println(vo+"vo");
		
		userService.insertUser(vo);
		
		return "index.html";
	}
	
	
	
}
