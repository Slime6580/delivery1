package com.slime.delivery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.slime.delivery.uservo.UserVO;
import com.slime.delivery.vo.DeliveryVO;

@Repository
public class UserDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	private final String INSERT_USER = "INSERT INTO users VALUE (?,?,?,?,?);";
	private final String USER_GET = "SELECT * FROM users where ID=? AND PW=?";
	
	public UserDAO() {
		System.out.println("UserDAO 지나가요");
	}
	
	
	public void insertUser(UserVO vo) {
		
		System.out.println("insertUserDAO");
		System.out.println(vo+"DAOVO");
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(INSERT_USER);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPw());
			pstmt.setString(3, vo.getNickName());
			pstmt.setString(4, vo.getDestination());
			pstmt.setString(5, vo.getPhoneNum());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}
	
	public List<UserVO> getUserList(UserVO vo) {
		System.out.println(USER_GET);
		List<UserVO> userList = new ArrayList<UserVO>();
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(USER_GET);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPw());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				UserVO user = new UserVO();
				user.setId(rs.getString("ID"));
				user.setPw(rs.getString("PW"));
				user.setNickName(rs.getString("NICKNAME"));
				user.setDestination(rs.getString("DESTINATION"));
				user.setPhoneNum(rs.getString("PHONENUM"));
				
				userList.add(user);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return userList;
	}
	
	
}
