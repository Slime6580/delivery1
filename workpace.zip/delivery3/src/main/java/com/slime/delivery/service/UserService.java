package com.slime.delivery.service;

import java.util.List;

import com.slime.delivery.uservo.UserVO;

public interface UserService  {

	void insertUser(UserVO vo);
	
	List<UserVO> UserList(UserVO vo); 
	
}
