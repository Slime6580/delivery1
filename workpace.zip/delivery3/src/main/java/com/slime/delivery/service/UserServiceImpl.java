package com.slime.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slime.delivery.dao.UserDAO;
import com.slime.delivery.uservo.UserVO;

@Service("UserService")
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDAO userDAO;
	
	public UserServiceImpl() {
		System.out.println("유저서비스인터페이스 호출");
	}

	@Override
	public void insertUser(UserVO vo) {
		System.out.println("insertUser");
		userDAO.insertUser(vo);
		
	}

	@Override
	public List<UserVO> UserList(UserVO vo) {
		
		return userDAO.getUserList(vo);
	}
	
}
