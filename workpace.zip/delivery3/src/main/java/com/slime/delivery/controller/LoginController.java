package com.slime.delivery.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.slime.delivery.dao.UserDAO;
import com.slime.delivery.service.UserService;
import com.slime.delivery.uservo.UserVO;

@Controller
public class LoginController{	
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="login.do", method=RequestMethod.GET)
	public String loginView(@ModelAttribute("user") UserVO vo) {
		System.out.println("로그인 화면으로 이동");
		vo.setId("test");
		vo.setPw("test123");
		return "login.jsp";
	}	
	
	@RequestMapping(value="login.do", method=RequestMethod.POST)
	public String login(UserVO vo, UserDAO userDAO, HttpServletRequest request) {
		
		System.out.println();
		
		System.out.println("로그인 인증 처리...");
		if (vo.getId() == null || vo.getId().equals("")) {
			throw new ArithmeticException("아이디는 반드시 입력해야 합니다.");
		}
		
		List<UserVO> user = userDAO.getUserList(vo);
		HttpSession sesstion = request.getSession();
		
		// 3. 화면 네비게이션  
		if(user != null){
			// 로그인 성공
			System.out.println("리스트 컨트롤러");
			userService.UserList(vo);
			System.out.println(userService.UserList(vo)+"로그인 겟 유저");
			System.out.println(user);
			
			sesstion.setAttribute("userinfo", user );
			
			return "index.jsp";
			
		} else {
			// 로그인 실패
			return "login.jsp";
		}
		
	}

}