package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class SelectDay {
	
	@RequestMapping(value="select.do", method=RequestMethod.POST)
	public String erabu(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String pattern = "yyyy/MM/dd";
		String setday = request.getParameter("setday");
		LocalDate now = LocalDate.now();
	
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern (pattern);
	
		LocalDateTime date = LocalDateTime.parse(setday, formatter);
		Duration diff = Duration.between(date, now);

		System.out.println("now :"+now);
		System.out.println("date :"+date);
		System.out.println("diff :"+diff);
		
		model.addAttribute("now", now);
		model.addAttribute("date", date);
		model.addAttribute("diff", diff);

		return "selectdays2.jsp";
		
		
		
	}
}
