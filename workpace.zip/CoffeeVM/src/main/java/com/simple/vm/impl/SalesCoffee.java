package com.simple.vm.impl;

public class SalesCoffee {

	private String CoffeeType;
	private int sum;
	
	public SalesCoffee() {
		// TODO Auto-generated constructor stub
	}

	public SalesCoffee(String coffeeType, int sum) {
		super();
		CoffeeType = coffeeType;
		this.sum = sum;
	}

	public String getCoffeeType() {
		return CoffeeType;
	}

	public void setCoffeeType(String coffeeType) {
		CoffeeType = coffeeType;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	@Override
	public String toString() {
		return "SalesCoffee [CoffeeType=" + CoffeeType + ", sum=" + sum + "]";
	}
	
	
	
	
	
}
