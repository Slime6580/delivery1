package com.simple.vo;

import java.sql.Date;

public class TimeVO {

	private Date day;
	private String type;
	
	public Date getDay() {
		return day;
	}
	public void setDay(Date day) {
		this.day = day;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "TimeVO [day=" + day + ", type=" + type + "]";
	}
	
	
	
	
}