package com.simple.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.simple.service.JDBCUtil;
import com.simple.vo.TimeVO;

@Repository
public class TimeDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	private final String Time_List = "SELECT * FROM dayoff;";

	public TimeDAO() {
		System.out.println("TimeDAO 객체 생성");
	}

	public List<TimeVO> getTimeList(TimeVO vo) {
		System.out.println("==> JDBC로 getTimeList() 기능처리 ");
		List<TimeVO> timeList = new ArrayList<TimeVO>();

		System.out.println(vo);
		try {

			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(Time_List);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				TimeVO time = new TimeVO();
				time.setDay(rs.getDate("DAY"));
				time.setType(rs.getString("TYPE"));

				timeList.add(time);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return timeList;
		
	}

}
