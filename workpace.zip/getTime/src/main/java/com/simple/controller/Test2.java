package com.simple.controller;

import java.text.ParseException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Test2 {
	public static void main(String[] args) throws ParseException {
		
		LocalDate setday3 = LocalDate.of(2024, 06, 03);
		
		LocalDate now = LocalDate.now();
	
		Period diff = Period.between(now, setday3);

		int dday = diff.getMonths()*(30) + diff.getDays();
		
		
		System.out.println("now :"+now);
		System.out.println("date :"+setday3);
		System.out.println("dday :"+dday);
		
	}
}
