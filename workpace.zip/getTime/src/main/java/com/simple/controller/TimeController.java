package com.simple.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.simple.dao.TimeDAO;
import com.simple.service.TimeService;
import com.simple.vo.TimeVO;

@Controller
@SessionAttributes("time")
public class TimeController {

	@Autowired
	TimeService timeService;
	
	@RequestMapping("/getTimeList.do")
	public String getTimeList(TimeVO vo, Model model, TimeDAO timeDAO) {
		
		System.out.println("확인");
		model.addAttribute("timeList", timeService.getTimeList(vo));
		System.out.println("DB");
		
		return "getTimeList.jsp";
		
	}
	
}