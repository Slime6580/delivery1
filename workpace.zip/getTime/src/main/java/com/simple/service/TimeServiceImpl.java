package com.simple.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simple.dao.TimeDAO;
import com.simple.vo.TimeVO;

@Service("timeService")
public class TimeServiceImpl implements TimeService {

	@Autowired
	private TimeDAO timeDAO;
	
	public TimeServiceImpl() {
		System.out.println("TimeServiceImpl 생성자 호출됨");
	}
	
	
	@Override
	public List<TimeVO> getTimeList(TimeVO vo) {
		
		return timeDAO.getTimeList(vo);
	}

}
