package com.simple.service;

import java.util.List;

import com.simple.vo.TimeVO;

public interface TimeService {

	List<TimeVO> getTimeList(TimeVO vo);
	
}
