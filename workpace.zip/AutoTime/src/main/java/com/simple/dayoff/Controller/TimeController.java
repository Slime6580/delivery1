package com.simple.dayoff.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.simple.dayoff.TimeDAO.TimeDAO;
import com.simple.dayoff.TimeService.TimeService;
import com.simple.dayoff.TimeVO.TimeVO;

@Controller
@SessionAttributes("time")
public class TimeController {

	@Autowired
	TimeService timeService;
	
	@
	public String getTimeList(TimeVO vo, Model model, TimeDAO timeDAO) {
		
		model.addAttribute("timeList", timeService.getTimeList(vo));
		
		return "getTimeList.jsp";
		
	}
	
}
