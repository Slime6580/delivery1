package com.simple.dayoff.TimeService;

import java.util.List;

import org.springframework.stereotype.Service;

import com.simple.dayoff.TimeDAO.TimeDAO;
import com.simple.dayoff.TimeVO.TimeVO;

@Service("timeService")
public class TimeServiceImpl implements TimeService {

	private TimeDAO timeDAO;
	
	public TimeServiceImpl() {
		System.out.println("TimeServiceImpl 생성자 호출됨");
	}
	
	
	@Override
	public List<TimeVO> getTimeList(TimeVO vo) {
		
		return timeDAO.getTimeList(vo);
	}

}
