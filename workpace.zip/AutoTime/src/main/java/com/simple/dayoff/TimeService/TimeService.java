package com.simple.dayoff.TimeService;

import java.util.List;

import com.simple.dayoff.TimeVO.TimeVO;

public interface TimeService {

	List<TimeVO> getTimeList(TimeVO vo);
	
}
