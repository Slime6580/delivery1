package com.slime.delivery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.slime.delivery.dao.DeliveryDAO;
import com.slime.delivery.service.DeliveryService;
import com.slime.delivery.vo.DeliveryVO;

@Controller
@SessionAttributes("delivery")
public class DeliveryController {

	@Autowired
	DeliveryService deliveryService;
	
	@RequestMapping("/brand.do")
	public String getDeliveryList (DeliveryVO vo, DeliveryDAO deliveryDAO, Model model) {
	
		System.out.println("컨트롤러 통과");
		
		model.addAttribute("deliveryList", deliveryService.DeliveryList(vo));
		
		System.out.println("deliveryService.DeliveryList(vo)" + deliveryService.DeliveryList(vo));
		return "brand.jsp";
		
	}
	
	@RequestMapping("/norang.do")
	public String getmenuList (DeliveryVO vo, DeliveryDAO deliveryDAO, Model model) {
	
		System.out.println("컨트롤러 통과");
		
		model.addAttribute("menuList", deliveryService.MenuList(vo));
		
		System.out.println("deliveryService.MenuList(vo)" + deliveryService.MenuList(vo));
		return "norang.jsp";
	
	
	}
}
