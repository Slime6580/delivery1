package com.slime.delivery.vo;

public class DeliveryVO {

	private String brandName;
	private String location;
	private String menu;
	private String brandImg;
	
	private String content;
	private int price;
	private int cal;
	private String cmenu;
	private String menuImg;
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getBrandImg() {
		return brandImg;
	}
	public void setBrandImg(String brandImg) {
		this.brandImg = brandImg;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCal() {
		return cal;
	}
	public void setCal(int cal) {
		this.cal = cal;
	}
	public String getCmenu() {
		return cmenu;
	}
	public void setCmenu(String cmenu) {
		this.cmenu = cmenu;
	}
	public String getMenuImg() {
		return menuImg;
	}
	public void setMenuImg(String menuImg) {
		this.menuImg = menuImg;
	}
	
	@Override
	public String toString() {
		return "DeliveryVO [brandName=" + brandName + ", location=" + location + ", menu=" + menu + ", brandImg="
				+ brandImg + ", content=" + content + ", price=" + price + ", cal=" + cal + ", cmenu=" + cmenu
				+ ", menuImg=" + menuImg + "]";
	}

	




}
