package com.slime.delivery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.slime.delivery.vo.DeliveryVO;

@Repository
public class DeliveryDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	private final String DELIVERY_LIST_B = "SELECT * FROM brand;";
	private final String DELIVERY_LIST_M = "SELECT * FROM menu\r\n" + "WHERE BRANDNAME = \"노랑 통닭\";";
	
	public DeliveryDAO() {
		System.out.println("DAO 객체 생성");
	}
	
	public List<DeliveryVO> getDeliveryList(DeliveryVO vo) {
		
		List<DeliveryVO> deliveryList = new ArrayList<DeliveryVO>();
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(DELIVERY_LIST_B);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				DeliveryVO delivery = new DeliveryVO();
				delivery.setBrandName(rs.getString("BRANDNAME"));
				delivery.setLocation(rs.getString("LOCATION"));
				delivery.setMenu(rs.getString("MENU"));
				delivery.setBrandImg(rs.getString("BRANDIMG"));
				
				deliveryList.add(delivery);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCUtil.close(rs, pstmt, conn);
			}
			
			return deliveryList;
		}
	
	public List<DeliveryVO> getMenuList(DeliveryVO vo) {
		
		List<DeliveryVO> menuList = new ArrayList<DeliveryVO>();
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(DELIVERY_LIST_M);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				DeliveryVO menu = new DeliveryVO();
				menu.setBrandName(rs.getString("BRANDNAME"));
				menu.setCmenu(rs.getString("CMENU"));
				menu.setContent(rs.getString("CONTENT"));
				menu.setPrice(rs.getInt("PRICE"));
				menu.setCal(rs.getInt("CAL"));
				menu.setMenuImg(rs.getString("MENUIMG"));
				
				menuList.add(menu);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCUtil.close(rs, pstmt, conn);
			}
			
			return menuList;
		}
	}