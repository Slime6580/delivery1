package com.slime.delivery.service;

import java.util.List;

import com.slime.delivery.vo.DeliveryVO;

public interface DeliveryService {

	List<DeliveryVO> DeliveryList(DeliveryVO vo);
	
	List<DeliveryVO> MenuList(DeliveryVO vo);
	
}
