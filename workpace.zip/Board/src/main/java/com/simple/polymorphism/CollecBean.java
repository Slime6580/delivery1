package com.simple.polymorphism;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class CollecBean {
	
	private Properties addressList;

	public Properties getAddressList() {
		return addressList;
	}

	public void setAddressList(Properties addressList) {
		this.addressList = addressList;
	}
	

}
