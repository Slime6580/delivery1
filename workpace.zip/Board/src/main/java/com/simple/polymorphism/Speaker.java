package com.simple.polymorphism;

public interface Speaker {
	public void volumeUp();
	public void volumeDown();
}
