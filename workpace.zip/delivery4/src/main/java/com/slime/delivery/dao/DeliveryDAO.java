package com.slime.delivery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.omg.CORBA.Request;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.slime.delivery.service.DeliveryService;
import com.slime.delivery.uservo.UserVO;
import com.slime.delivery.vo.DeliveryVO;

@Repository
public class DeliveryDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	private final String DELIVERY_LIST_B = "SELECT * FROM brand;";

	private final String DELIVERY_LIST_M = "SELECT * FROM menu WHERE BRANDNAME =?";

	private final String DELIVERY_LIST_S = "SELECT * FROM side WHERE BRANDNAME =?";

	private final String INSERT_ORDER = "INSERT INTO orders value (?,?,?,?,?,?,?,?);";
	
	private final String DELIVERY_LIST_O = "SELECT * FROM orders where id=? order by orderNum desc";

	public DeliveryDAO() {
		System.out.println("DAO 객체 생성");
	}

	public List<DeliveryVO> getDeliveryList(DeliveryVO vo) {

		List<DeliveryVO> deliveryList = new ArrayList<DeliveryVO>();

		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(DELIVERY_LIST_B);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				DeliveryVO delivery = new DeliveryVO();
				delivery.setBrandName(rs.getString("BRANDNAME"));
				delivery.setLocation(rs.getString("LOCATION"));
				delivery.setMenu(rs.getString("MENU"));
				delivery.setBrandImg(rs.getString("BRANDIMG"));

				deliveryList.add(delivery);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}

		return deliveryList;
	}

	public List<DeliveryVO> getMenuList(String brandName) {

		List<DeliveryVO> menuList = new ArrayList<DeliveryVO>();

		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(DELIVERY_LIST_M);
			pstmt.setString(1, brandName);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				DeliveryVO menu = new DeliveryVO();
				menu.setBrandName(rs.getString("BRANDNAME"));
				menu.setCmenu(rs.getString("CMENU"));
				menu.setContent(rs.getString("CONTENT"));
				menu.setPrice(rs.getInt("PRICE"));
				menu.setCal(rs.getInt("CAL"));
				menu.setMenuImg(rs.getString("MENUIMG"));

				menuList.add(menu);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}

		return menuList;
	}

	public List<DeliveryVO> getSideList(String brandName) {

		List<DeliveryVO> sideList = new ArrayList<DeliveryVO>();

		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(DELIVERY_LIST_S);
			pstmt.setString(1, brandName);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				DeliveryVO side = new DeliveryVO();
				side.setBrandName(rs.getString("BRANDNAME"));
				side.setSideMenu(rs.getString("SIDEMENU"));
				side.setPrice(rs.getInt("PRICE"));

				sideList.add(side);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}

		return sideList;
	}

	public void insertOrder(DeliveryVO vo1, UserVO vo2) {

		System.out.println("DAO insertOrder");

		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(INSERT_ORDER);
			pstmt.setString(1, vo2.getId());
			pstmt.setString(2, vo2.getDestination());
			pstmt.setString(3, vo2.getPhoneNum());
			pstmt.setString(4, vo1.getBrandName());
			pstmt.setString(5, vo1.getCmenu());
			pstmt.setString(6, vo1.getSideMenu());
			pstmt.setInt(7, vo1.getTotal());
			pstmt.setInt(8, vo1.getOrderNum());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}

	public List<DeliveryVO> getOrderList(String id) {
		List<DeliveryVO> orderList = new ArrayList<DeliveryVO>();
		
			try {
				conn = JDBCUtil.getConnection();
				pstmt = conn.prepareStatement(DELIVERY_LIST_O);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
		
				while (rs.next()) {
					DeliveryVO order = new DeliveryVO();
					order.setId(rs.getString("id"));
					order.setDestination(rs.getString("destination"));
					order.setPhoneNum(rs.getString("phoneNum"));
					order.setBrandName(rs.getString("brandName"));
					order.setCmenu(rs.getString("cmenu"));
					order.setSideMenu(rs.getString("sideMenu"));
					order.setTotal(rs.getInt("total"));
					order.setOrderNum(rs.getInt("orderNum"));
					
					orderList.add(order);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCUtil.close(rs, pstmt, conn);
			}
		return orderList;
	}

}

