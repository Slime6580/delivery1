package com.slime.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slime.delivery.dao.DeliveryDAO;
import com.slime.delivery.dao.UserDAO;
import com.slime.delivery.uservo.UserVO;
import com.slime.delivery.vo.DeliveryVO;

@Service("deliveryService")
public class DeliveryServiceImpl implements DeliveryService {

	@Autowired
	private DeliveryDAO deliveryDAO;
	
	
	
	public DeliveryServiceImpl() {
		System.out.println("Service 생상자 호출");
	}
	
	@Override
	public List<DeliveryVO> deliveryList(DeliveryVO vo) {
		
		System.out.println("Service1");
		
		return deliveryDAO.getDeliveryList(vo);
	}

	@Override
	public List<DeliveryVO> menuList(String brandName) {
		deliveryDAO.getMenuList(brandName);
		return deliveryDAO.getMenuList(brandName);
	}

	@Override
	public List<DeliveryVO> sideList(String brandName) {
		deliveryDAO.getSideList(brandName);
		return deliveryDAO.getSideList(brandName);
	}

	@Override
	public void insertOrder(DeliveryVO vo1, UserVO vo2) {
		deliveryDAO.insertOrder(vo1, vo2);
	}

	@Override
	public List<DeliveryVO> orderList(String id) {
		
		return deliveryDAO.getOrderList(id);
	}

}
